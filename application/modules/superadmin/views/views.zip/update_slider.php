<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Create Menu </title><!-- 
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />
	
  </head>
  <body>
	<?php include('includes/header.php'); ?>
	<!-- content Starts  hear  -->	

		<div class="col-md-12"> 
			<ol class="breadcrumb breadcrumb-arrow">
				<li><a href="<?php echo base_url().'dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
				<li><a href="">Category</a></li>
				<li class="active"><span>Update Slider </span></li>
			</ol>
		</div> 
	<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="" style="padding:15px">
					<h3> <b> Update Slider </b></h3>
				</div>
				
				<div class="panel-body">
					<div class="col-md-12">
					<?php //if(!empty($result)){extract($result); echo $msg;} ?>						<?php if($this->session->flashdata('message')){?>
			          <div class="alert alert-success">      
			            <?php echo $this->session->flashdata('message')?>
			          </div>
			        <?php } ?> 
			       
						<?php echo form_open_multipart('superadmin/Category/updateSlider/'); ?>
		                   
		                   <?php if(validation_errors()){ ?>
					    <div class="alert alert-danger">
					       <?php echo validation_errors();?>
					       </div> 
					    <?php
					       }
					    ?>	 
					    	<?php 
					    	echo form_hidden('slider_id',$result->id); 
					    	echo form_hidden('old_image',$result->slider_image);
					    	echo form_hidden('old_app_icon',$result->slider_app_image); 
					    	?>
								<div class="form-group col-md-4"> 
									<?php echo form_label('Slider Title','Slider Title');?><span class="text-danger"><?php echo form_error('slider_title'); ?></span>
									<?php
									$data = array(
											        'name'          => 'slider_title',
											        'id'            => 'slider_title',
											        'maxlength'     => 40,
											        'autocomplete'  => 'off',
											        'class'			=> 'form-control',
											        'placeholder'	=> 'Enter Slider Title',
											        'value'			=> $result->slider_title

											);

						        	 echo form_input($data);
						         ?>
									
								</div>
						        <div class="form-group col-md-4">
						        <?php echo form_label('Slider URL','Slider URL');?><span class="text-danger"><?php echo form_error('slider_url'); ?></span>
						<?php echo form_input(array('class'=>'form-control','name'=>'slider_url','id'=>'slider_url','placeholder'=>'Enter Slider URL','value'=>$result->slider_url,'autocomplete'=>'off')); ?>
						         	 <!-- <input type="text" class="form-control" placeholder="Enter Slider URL" name="slider_url"> -->
						        </div>
						        <div class="clearfix"> </div>
						        <div class="form-group col-md-4"> 
						        	<?php echo form_label('Slider Image ','Slider Image');?><span class="text-danger"><?php echo form_error('slider_image'); ?></span>
						        	<!-- <label for="Image">Slider Image (250 X 150) </label> -->
									<input type="file" name="image" class="form-control">
								</div>
								<div class="form-group col-md-4"> 
						        	<label for="Image">Slider App Icon (100 X 80) </label>
									<input type="file" name="icon" class="form-control">
								</div>
								<div class="clearfix"> </div>
								<div class="form-group col-md-8"> 
								<?php echo form_label('Description ','Description');?><span class="text-danger"><?php echo form_error('slider_description'); ?></span>
						        	
									<textarea rows="5" cols="30" class="form-control" placeholder="Description " name="slider_description"><?php echo $result->slider_description;?> </textarea>
								</div>
								
								<div class="clearfix"> </div>
								<div class="form-group col-md-8 ">
								 	<div class="pull-right"> 
						        	<?php echo form_submit('submit','Submit',array('class'=>'btn btn-success ','name'=>'btn_submit','id'=>'btn_submit')); ?>
						        	<a href="<?php echo base_url().'superadmin/Screens/createslider'; ?> " class="btn btn-primary btn-md 	"> <i class="glyphicon glyphicon-eye-open"></i> View Sliders</a>
						        	</div> 
								</div>
						        	
						        	
						    <?php echo form_close(); ?>
	                      <span class="help_block"></span>
	                </div>
				</div>
			</div>
		</div>
		<!-- content ends hear  -->				
    <?php include('includes/footer.php'); ?>	
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>additional-methods.min.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jkvalidate.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.validate.min"></script>
  </body>
</html>