<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Create Menu </title><!-- 
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />
	
  </head>
  <body>
	<?php include('includes/header.php'); ?>
	<!-- content Starts  hear  -->	

		<div class="col-md-12"> 
			<ol class="breadcrumb breadcrumb-arrow">
				<li><a href="<?php echo base_url().'dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
				<li><a href="">Slider</a></li>
				<li class="active"><span>Create Slider </span></li>
			</ol>
		</div> 
	<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="" style="padding:15px">
					<h3> <b> Create Slider </b></h3>
				</div>
				
				<div class="panel-body">
					<div class="col-md-12">
					<?php //if(!empty($result)){extract($result); echo $msg;} ?>						<?php if($this->session->flashdata('message')){?>
			          <div class="alert alert-success">      
			            <?php echo $this->session->flashdata('message')?>
			          </div>
			        <?php } ?> 

							<?php

							$attribute = array('name' =>'form' ,'id'=> 'register-form');
							 echo form_open_multipart('superadmin/Category/createslider',$attribute); ?>
								<div class="form-group col-xs-4"> 
									<?php echo form_label('Slider Title','Slider Title');?><span style="color:red;">*<?php echo form_error('slider_title'); ?></span>
									<?php
									$data = array(
									        'name'          => 'slider_title',
									        'id'            => 'slider_title',
									        'maxlength'     => 40,
									        'autocomplete'  => 'off',
									        'class'			=> 'form-control',
									        'placeholder'	=> 'Enter Slider Title',
									        'value'			=>set_value('slider_title')


											);

						        	 echo form_input($data);
						         ?>
									
								</div>
						        <div class="form-group col-xs-4">
						        <?php echo form_label('Slider URL','Slider URL');?><span style="color:red;">*
						        <?php echo form_error('slider_url'); ?></span>
						<?php echo form_input(array('class'=>'form-control','name'=>'slider_url','id'=>'slider_url','placeholder'=>'Enter Slider URL','value'=>set_value('slider_url'),'autocomplete'=>'off')); ?>
						         	 <!-- <input type="text" class="form-control" placeholder="Enter Slider URL" name="slider_url"> -->
						        </div>
						        <div class="clearfix"> </div>
						        <div class="form-group col-xs-4"> 
						        	<?php echo form_label('Slider Image ','Slider Image');?><span class="text-danger"><?php echo form_error('slider_image'); ?></span>
						        	<!-- <label for="Image">Slider Image (250 X 150) </label> -->
									<input type="file" name="image" class="form-control">
								</div>
								<div class="form-group col-xs-4"> 
						        	<label for="Image">Slider App Icon (100 X 80) </label>
									<input type="file" name="icon" class="form-control">
								</div>
								<div class="clearfix"> </div>
								<div class="form-group col-xs-8"> 
								<?php echo form_label('Description ','Description');?><span style="color:red;" >*<?php echo form_error('slider_description'); ?></span>
						        	
									<textarea rows="5" cols="30" class="form-control" placeholder="Description " name="slider_description" style=""> </textarea>
								</div>
								
								<div class="clearfix"> </div>
								<div class="form-group col-xs-4 pull-right"> 
						        	<?php echo form_submit('submit','Submit',array('class'=>'btn btn-success','name'=>'btn_submit','id'=>'btn_submit')); ?>
						        	<a href="<?php echo base_url().'superadmin/Screens/createslider'; ?> " class="btn btn-primary btn-md	"> <i class="glyphicon glyphicon-eye-open"></i> View Sliders</a>
								</div>
						        	
						        	
						    <?php echo form_close(); ?>
	                      <span class="help_block"></span>
	                </div>
				</div>
			</div>
		</div>
		<!-- content ends hear  -->				
    <?php include('includes/footer.php'); ?>	
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>additional-methods.min.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jkvalidate.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.validate.min"></script>
  </body>
</html>

<script>
$(function(){
	 $.validator.setDefaults({
    errorClass: 'help-block',
    highlight: function(element) {
      $(element)
        .closest('.form-group')
        .addClass('has-error');
    },
    unhighlight: function(element) {
      $(element)
        .closest('.form-group')
        .removeClass('has-error');
    },
    errorPlacement: function (error, element) {
      if (element.prop('type') === 'checkbox') {
        error.insertAfter(element.parent());
      } else {
        error.insertAfter(element);
      }
    }
  });

  $.validator.addMethod('strongPassword', function(value, element) {
    return this.optional(element) 
      || value.length >= 6
      && /\d/.test(value)
      && /[a-z]/i.test(value);
  }, 'Your password must be at least 6 characters long and contain at least one number and one char\'.')

	$("#register-form").validate({
		rules:{
			//name fields

			slider_title:{
				required:true
				 
				
			},
			
			slider_url:{
				required:true
			},
			
			slider_description:{
				required:true
			}
			
			
			
		},
		messages:{
			required:'Please Enter Your Email',
			email:'please enter a valid email address'
		}
	});
	
});
</script>