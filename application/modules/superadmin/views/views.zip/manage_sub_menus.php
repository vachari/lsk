	<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Super Admin </title><!-- 
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />
	<style>
 	p{
			display: inline-block;
		    padding-left: 0;
		    margin: 20px 0;
		    border-radius: 4px;} 
		  p a{
		  	position:;
		    float: ;
		    padding: 6px 12px;
		    margin-left: -1px;
		    line-height: 1.42857143;
		    color: #337ab7;
		    text-decoration: none;
		    background-color: #fff;
		    border: 1px solid #ddd;
		    }
		   p>a:hover{
			z-index: 2;
		    color: #23527c;
		    background-color: #eee;
		    border-color: #ddd;
				
		   } 
		  p strong{
		  	background-color: #337ab7;
			padding: 6px 12px;
			color:#fff;
			border-color: #fff;

		  }


</style>
  </head>
  <body>
  <?php
     $result=json_decode($common_result);
     // print_r($result->common_result); 

      ?>
		<?php include('includes/header.php'); ?>
            	<div class="col-md-12"> 
					<ol class="breadcrumb breadcrumb-arrow">
						<li><a href="<?php echo base_url().'superadmin/dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
						<li><a href="">Category</a></li>
						<li class="active"><span>Manage Sub Category </span></li>
					</ol>
				</div> 
				
					<div class="col-lg-12">
							
							<div class="panel panel-default">
								<!-- <div class="col-md-12"> 
									<ol class="breadcrumb breadcrumb-arrow">
										<li><a href="dashboard.html"><i class="glyphicon glyphicon-th" aria-hidden="true"></i> Dashboard</a></li>
										<li><a href="">Hostel Owners</a></li>
										<li class="active"><span>Manage All Hostels</span></li>
									</ol>
								</div>  -->
								<div class="" style="padding:15px">
									<h3> <b> Manage Sub Menus	 </b></h3>
								</div>
								
								<!-- /.panel-heading -->
								<div class="panel-body">
									<div class="col-md-12"> 
										<table width="100%" class="table " id="">
										<thead>
											
											<tr>
												<td> 
													<div class="input-group">
													  
													  <input type="text" class="form-control" placeholder="Search for...">
													  <span class="input-group-btn">
														<button class="btn btn-secoundary" type="button"><i class="glyphicon glyphicon-search"></i></button>
													  </span>
													</div>
												</td>
												<td> 
													<select name=" " id="" class="form-control">
														<option value=" "> --Select Your Option-- </option>
														<option value=" "> Option one </option>
														<option value=" "> Option two </option>
														<option value=" "> Option Three </option>
													
													</select>
												</td>
												<td> 
													<a href="" class="btn btn-sm btn-success "> <i class="glyphicon glyphicon-ok"></i> Active </a> 
													<a href="" class="btn btn-sm btn-warning "><i class="glyphicon glyphicon-ban-circle"></i>   In Active  </a> 
                                                    <a href="" class="btn btn-sm btn-primary " ><i class="glyphicon glyphicon-plus"></i>  Create New </a> 
                                                    <a href="" class="btn btn-sm btn-info "><i class="glyphicon glyphicon-sort-by-order"></i>  Set Priority </a> 
													<a href="" class="btn btn-sm btn-danger "><i class="glyphicon glyphicon-remove"></i>  Delete </a> 
												</td>
												
											</tr>
										</thead>
										
										</table>
										
										
									</div>
									<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
										<thead>
											
											<tr>
												<th>
													<input type="checkbox" id="checkAll" >
												</th>
												<th>Sl.No</th>
												<th> Menu Name </th>
												<th> Sub Menu Title </th>
												<th> Submenu Banner </th>
												<th> Submenu App Icon</th>
												<th> Created Date </th>
												<th> Created IP-Address</th>
												<th> Flag Status</th>
												<th> Priority</th>
												<th> Status</th>
												<th> Action  </th>
											</tr>
										</thead>
										<tbody>
											<?php 
													$i=1;

												foreach ($result->common_result as $row) {
											?>
											<tr class="">
												<td><input type="checkbox" class="checkbox" name="checkbox[]" > </td>
												<td><?php echo $i; ?> </td>
												<td>  
													 <?php
                                                  foreach ($menu_result as $menu) {
                                                      if($row->menu_id==$menu->menu_id){
                                                            echo $menu->menu_title;}
                                                      }  
                                                  ?>
													
												</td>
												<td> <?php echo $row->submenu_title; ?> </td>
												<td>
												<?php if(!empty($row->submenu_banner)){ ?>
												<img src="<?php echo base_url();?>uploads/submenu/<?php echo $row->submenu_banner; ?>" style="width:75px;height:50px" /> 
												<?php }
												 else{
												 	echo "NO IMAGE"; 

												 }
												 ?>	
												</td>
												<td>
													<?php if(!empty($row->submenu_app_icon)){ ?>
												<img src="<?php echo base_url();?>uploads/submenu/<?php echo $row->submenu_app_icon; ?>" style="width:75px;height:50px" /> 
												<?php }
												 else{
												 	echo "NO IMAGE"; 

												 }
												 ?>

												</td>
												<td> <?php echo $row->created_date; ?> </td>
												<td> <?php echo $row->created_ipaddress; ?></td>
												<td> 1 </td>
												<td> Priority </td>
												<td class="text-success"><b> Active  </b></td>
												<td> 
		<a href="<?php echo base_url(); ?>superadmin/deletesubmenu/<?php echo $row->submenu_id; ?>" class="btn btn-sm btn-danger " onclick="return confirm('Are you sure?')"> <i class="glyphicon glyphicon-trash"></i> </a>
		<a href="<?php echo base_url(); ?>superadmin/Category/get_sub_menu/<?php echo $row->submenu_id; ?>" class="btn btn-sm btn-warning "> <i class="glyphicon glyphicon-upload"> </i> </a>
												</td>
											</tr>
											<?php 
												$i++ ;}
											?>
											
										</tbody>
									</table>
									<!-- /.table-responsive -->
									
						<div class="text-center"> 
								<p> <?php echo $links; ?></p>

						</div>
								</div>
								
								<!-- /.panel-body -->
							</div>
							<!-- /.panel -->
							
						</div>
						<!-- /.col-lg-12 -->
    			<?php include('includes/footer.php'); ?>	
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
  </body>
</html>
<script type="text/javascript">
	$("#checkAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});



</script>