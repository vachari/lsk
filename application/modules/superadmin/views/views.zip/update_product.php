<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Create Product </title><!-- 
            <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>default.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>jquery.datetimepicker.css"/>
    </head>
    <style>
        .err_class{color:red}
    </style>
    <body>
        <?php include('includes/header.php'); ?>
        <!-- content Starts  hear  -->	

        <div class="col-md-12"> 
            <ol class="breadcrumb breadcrumb-arrow">
                <li><a href="<?php echo base_url() . 'dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
                <li><a href="">Products</a></li>
                <li class="active"><span>Update Product</span></li>
            </ol>
        </div> 
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="" style="padding:15px">
                    <h3> <b> Update Product </b></h3>
                    <?php if (validation_errors()) { ?>
                        <div class="alert alert-danger">
                            <?php echo validation_errors(); ?>
                        </div> 
                        <?php

                    }
                  
                    ?>
                </div>
                <div class="panel-body">
                    <div class="col-md-12"> 
                        <div class="form-group col-xs-4">
                            <?php
                            $form_attributes = array('id' => 'insertproduct', 'name' => 'insertproduct');
                            echo form_open('superadmin/Category/updateProduct', $form_attributes);
                            echo form_label('Menu', 'Menu');
                             //print_r($menu_result[0]->menu_title);
                            ?>
                             <?php form_hidden('prod_id',$result->prod_id); ?>
                            <span style="color:red;"> *</span> 
                            <select name="menu_id" id="menu_id" class="form-control ">
                            <option value="<?php echo $menu_result[0]->menu_id; ?>"><?php echo $menu_result[0]->menu_title; ?></option>
                                <?php
                                  
                                $menu_req = json_decode($menu_result);
                                if ($menu_req->code == SUCCESS_CODE) {
                                    foreach ($menu_req->menu_list as $menu_response) {
                                        ?>
                                        <option value="<?php echo $menu_response->menu_id; ?>"><?php echo $menu_response->menu_title; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                            <span class="err_class" id="menu_err"></span>
                        </div>
                        <div class="form-group col-xs-4">

                            <?php echo form_label('Submenu', 'Sub Menu'); ?>
                            <span style="color:red;"> *</span> 
                            <select name="submenu_id" id="submenuenu_id" class="form-control ">
                                 <option value="<?php echo $menu_result[0]->menu_id; ?>" ><?php echo $menu_result[0]->menu_title; ?>
                            </select>
                            <span class="err_class" id="submenu_err"></span>
                        </div>
                        <div class="clearfix"></div>
                        <div class="form-group col-xs-4">

                            <?php echo form_label('List Submenu', 'List Submenu'); ?>
                            <span style="color:red;"> *</span> 
                            <select name="listsubmenu" id="listsubmenu" class="form-control ">
                                <option value="<?php echo $menu_result[0]->menu_id; ?>"><?php echo $menu_result[0]->menu_title; ?>
                            </select>
                            <span class="err_class" id="listsubmenu_err"></span>
                        </div>
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data1 = array(
                            'name' => 'product_code',
                            'id' => 'product_code',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control',
                            'placeholder' => 'Product Code',
                            'value' =>$result->prod_code

                        );
                        echo form_label('Product Code', 'Product Code');
                        echo form_input($data1);
                        ?>
                        <span class="err_class" id="prod_code_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <div class="clearfix"></div>
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data1 = array(
                            'name' => 'product_title',
                            'id' => 'product_title',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control',
                            'placeholder' => 'Product Name',
                            'value' =>$result->prod_title
                        );
                        echo form_label('Product Title', 'Product Title');
                        echo form_input($data1);
                        ?>
                        <span class="err_class" id="prod_title_err"></span>
                        <?php
                        echo "</div>";
                        ?>


                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data2 = array(
                            'name' => 'sku_qty',
                            'id' => 'sku_qty',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'SKU Qty',
                            'value' =>$result->prod_skuqty
                        );
                        echo form_label('SKU Qty', 'SKU Qty') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="prod_skuqty_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <div class="clearfix"></div>
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data3 = array(
                            'name' => 'qty_from',
                            'id' => 'qty_from',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Total Order Qty From',
                            'value' =>$result->total_order_qty_from
                        );
                        echo form_label('Total Order Qty From', 'Total Order Qty From') . "<span style='color:red'> *</span>";
                        echo form_input($data3);
                        ?>
                        <span class="err_class" id="order_to_err"></span>
                        <?php
                        echo "</div>";
                        ?>	
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data3 = array(
                            'name' => 'qty_to',
                            'id' => 'qty_to',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Total Order Qty To',
                            'value' =>$result->total_order_qty_to
                        );
                        echo form_label('Total Order Qty To', 'Total Order Qty To') . "<span style='color:red'> *</span>";
                        echo form_input($data3);
                        ?>
                        <span class="err_class" id="order_from_err"></span>                   
                        <?php
                        echo "</div>";
                        ?>
                        <div class="clearfix"></div>
                        <div class="form-group col-xs-4">

                            <?php echo form_label('Product Display From Date', 'Product Display From Date'); ?>
                            <span style="color:red;"> *</span> 
                            <input type="text" class='form-control bookingdate_class' name="prod_from_date" id="prod_from_date"  value="<?php echo $date_result->prod_avail_from_date; ?>" />
                            <span class="err_class" id="prod_disfrom_err"></span> 
                        </div>
                        <div class="form-group col-xs-4">

                            <?php echo form_label('Product Display To Date', 'Product Display To Date'); ?>
                            <span style="color:red;"> *</span> 
                            <input type="text" class='form-control bookingdate_class' name="prod_to_date" id="prod_to_date" value="<?php echo $date_result->prod_avail_to_date; ?>" />
                            <span class="err_class" id="prod_disto_err"></span> 
                        </div>
                        <div class="clearfix"></div>
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data4 = array(
                            'name' => 'mrp',
                            'id' => 'mrp',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'MRP',
                            'value' =>$result->mrp
                        );
                        echo form_label('MRP', 'MRP') . "<span style='color:red'> *</span>";
                        echo form_input($data4);
                        ?>
                        <span class="err_class" id="prod_mrp_err"></span>                    
                        <?php
                        echo "</div>";
                        ?>	

                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data5 = array(
                            'name' => 'selling_price',
                            'id' => 'selling_price',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Selling Price',
                            'value' =>$result->sellingprice
                        );
                        echo form_label('Selling Price', 'Selling Price') . "<span style='color:red'> *</span>";
                        echo form_input($data5);
                        ?>
                        <span class="err_class" id="prod_sp_err"></span> 
                        <?php
                        echo "</div>";
                        ?>
                        <div class="clearfix"></div>
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data6 = array(
                            'name' => 'stock',
                            'id' => 'stock',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Available Stock',
                            'value' =>$result->stock
                        );
                        echo form_label('Available Stock', 'Available Stock') . "<span style='color:red'> *</span>";
                        echo form_input($data6);
                        ?>
                        <span class="err_class" id="prod_stock_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data6 = array(
                            'name' => 'moq',
                            'id' => 'moq',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control',
                            'placeholder' => 'MOQ',
                            'value' =>$result->moq
                        );
                        echo form_label('MOQ', 'MOQ') . "<span style='color:red'> *</span>";
                        echo form_input($data6);
                        ?>
                        <span class="err_class" id="prod_moq_err"></span>
                        <?php
                        echo "</div>";
                        ?>	
                        <div class="clearfix"></div>	
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data6 = array(
                            'name' => 'truckqty',
                            'id' => 'truckqty',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control',
                            'placeholder' => 'Truck Load Qty',
                            'value' =>$result->truckloadqty
                        );
                        echo form_label('Truck Load Qty', 'Truck Load Qty') . "<span style='color:red'> *</span>";
                        echo form_input($data6);
                        ?>
                        <span class="err_class" id="prod_truckqty_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <div class="form-group col-xs-4"> 
                            <?php echo form_label('IMAGE (250 X 150)', 'IMAGE (250 X 150)'); ?>
                            <span style="color:red;"> *</span> 

                            <?php
                            $upload1 = array(
                                'name' => 'image',
                                'id' => 'image',
                                'class' => 'form-control',
                                'multiple' => 'multiple'
                            );

                            echo form_upload($upload1);
                            ?>
                            <span class="err_class" id="prod_img_err"></span>
                        </div>

                        <div class="clearfix"> </div>
                        <div class="form-group col-xs-4">

                            <?php echo form_label('Vendor', 'Vendor'); ?>
                            <span style="color:red;"> *</span> 
                            <input type="text" name="seller" id="seller" placeholder="Vendor ID" class="form-control" value="<?php echo $result->vendor; ?>" />
                            <span class="err_class" id="prod_vendor_err"></span>
                        </div>
                        <div class="clearfix"> </div>
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data6 = array(
                            'name' => 'description',
                            'id' => 'description',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control',
                            'placeholder' => 'Distribution Package Description',
                            'value' =>$result->distributiondesc
                        );
                        echo form_label('Distribution Package Description', 'Distribution Package Description') . "<span style='color:red'> *</span>";
                        echo form_textarea($data6);
                        ?>
                        <span class="err_class" id="description_err"></span>
                        <?php
                        echo "</div>";
                        ?>

                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data1 = array(
                            'name' => 'product_description',
                            'id' => 'product_description',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control',
                            'placeholder' => 'Product Description',
                            'value' =>$result->prod_desc
                        );
                        echo form_label('Product Description', 'Product Description');
                        echo form_textarea($data1);
                        ?>
                        <span class="err_class" id="prod_desc_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <div class="clearfix"> </div>
                        <span class="success_msg" style="color:green;"></span></br>
                        <span class="fail_msg" style="color:red;"></span>
                        <div class="form-group col-xs-8 pull-right"> 
                            <?php echo form_submit('submit', 'Submit', array('class' => 'btn btn-success', 'name' => 'btn_submit', 'id' => 'btn_submit')); ?>

                            <a href="<?php echo base_url() . 'superadmin/Category/manageproducts'; ?> " class="btn btn-primary btn-md	"> <i class="glyphicon glyphicon-eye-open"></i> View Product List</a>
                        </div>
                        <?php echo form_close(); ?>
                        <span class="help_block"></span>
                    </div>
                </div>
            </div>
        </div>
        <!-- content ends hear  -->				
        <?php include('includes/footer.php'); ?>	
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
        <script src="<?php echo SUPER_JS_PATH; ?>jquery.datetimepicker.full.js"></script>
        <script>
            $.datetimepicker.setLocale('en');
            var currentTime = new Date();
            var extendDate = new Date(currentTime.getFullYear(), currentTime.getMonth() + 1, currentTime.getDate());
            $('#datetimepicker').datetimepicker({value: new Date(), minDate: new Date(), maxDate: extendDate, format: "d-m-Y H:i", minTime: '10', pickTime: false, timepicker: true, }).css({'color': '#000', 'background-color': '#F6FBFC'});
            $('.bookingdate_class').datetimepicker({
                minDate: new Date(), maxDate: extendDate, format: "d-m-Y H:i", minTime: '10', pickTime: false, timepicker: true,
            }).css({'color': '#000', 'background-color': '#F6FBFC'});
            //$('#datetimepicker').timepicker( 'option', 'hours', {starts: 05, ends: 23});

        </script>
        <script type="text/javascript">
            $('#insertproduct').on('submit', function (i) {
                i.preventDefault();
                var str = true;
                $('#description_err,#prod_mrp_err,#submenu_err,#menu_err,#listsubmenu_err,#prod_code_err,#prod_title_err,#prod_desc_err,#prod_skuqty_err,#order_to_err,#order_from_err,#prod_disfrom_err,#prod_disto_err,#prod_sp_err,#prod_truckqty_err,#prod_moq_err,#prod_stock_err,#prod_img_err,#prod_vendor_err').html('');
                $('#menu_id,#submenu_id,#listsubmenu,#product_code,#product_title,#product_description,#sku_qty,#qty_from,#qty_to,#prod_from_date,#prod_to_date,#mrp,#selling_price,#stock,#moq,#truckqty,#image,#seller,#description').css('border', '');
                var menu = $('#menu_id').val();
                var submenu = $('#submenu_id').val();
                var listsubmenu = $('#listsubmenu').val();
                var prodcode = $('#product_code').val();
                var prodtitle = $('#product_title').val();
                var proddesc = $('#product_description').val();
                var prodskuqty = $('#sku_qty').val();
                var prodqtyfrom = $('#qty_from').val();
                var prodqtyto = $('#qty_to').val();
                var proddatefrom = $('#prod_from_date').val();
                var proddateto = $('#prod_to_date').val();
                var mrp = $('#mrp').val();
                var sellingprice = $('#selling_price').val();
                var stock = $('#stock').val();
                var moq = $('#moq').val();
                var truckordqty = $('#truckqty').val();
                var image = $('#image').val();
                var seller = $('#seller').val();
                var description = $('#description').val();
                if (menu == '') {
                    $('#menu_err').html('Please select menu');
                    $('#menu_id').css('border', '1px solid red');
                    str = false;
                }
                if (submenu == '') {
                    $('#submenu_err').html('Please select submenu');
                    $('#submenu_id').css('border', '1px solid red');
                    str = false;
                }
                if (listsubmenu == '') {
                    $('#listsubmenu_err').html('Please select listsubmenu');
                    $('#listsubmenu_id').css('border', '1px solid red');
                    str = false;
                }
                if (prodcode == '') {
                    $('#prod_code_err').html('Please enter product code');
                    $('#product_code').css('border', '1px solid red');
                    str = false;
                }
                if (prodtitle == '') {
                    $('#prod_title_err').html('Please enter product title');
                    $('#product_title').css('border', '1px solid red');
                    str = false;
                }
                if (proddesc == '') {
                    $('#prod_desc_err').html('Please enter product description');
                    $('#product_description').css('border', '1px solid red');
                    str = false;
                }

                if (prodskuqty == '') {
                    $('#prod_skuqty_err').html('Please enter product sku qty');
                    $('#sku_qty').css('border', '1px solid red');
                    str = false;
                }
                if (prodqtyfrom == '') {
                    $('#order_from_err').html('Please enter from product qty load');
                    $('#qty_from').css('border', '1px solid red');
                    str = false;
                }
                if (prodqtyto == '') {
                    $('#order_to_err').html('Please enter to product qty load');
                    $('#qty_to').css('border', '1px solid red');
                    str = false;
                }
                if (mrp == '') {
                    $('#prod_mrp_err').html('Please enter product mrp');
                    $('#mrp').css('border', '1px solid red');
                    str = false;
                }
                if (sellingprice == '') {
                    $('#prod_sp_err').html('Please enter product selling price');
                    $('#selling_price').css('border', '1px solid red');
                    str = false;
                }
                if (stock == '') {
                    $('#prod_stock_err').html('Please enter product stock');
                    $('#stock').css('border', '1px solid red');
                    str = false;
                }
                if (moq == '') {
                    $('#prod_moq_err').html('Please enter product MOQ');
                    $('#moq').css('border', '1px solid red');
                    str = false;
                }
                if (truckordqty == '') {
                    $('#prod_truckqty_err').html('Please enter product truck order qty');
                    $('#truckqty').css('border', '1px solid red');
                    str = false;
                }
                if (seller == '') {
                    $('#prod_vendor_err').html('Please slect product added vendor');
                    $('#seller').css('border', '1px solid red');
                    str = false;
                }
                if (description == '') {
                    $('#description_err').html('Please enter description');
                    $('#description').css('border', '1px solid red');
                    str = false;
                }
                if (proddatefrom == '') {
                    $('#prod_disfrom_err').html('Please select product display from date');
                    $('#prod_from_date').css('border', '1px solid red');
                    str = false;
                }
                if (proddateto == '') {
                    $('#prod_disto_err').html('Please select product display to date');
                    $('#prod_to_date').css('border', '1px solid red');
                    str = false;
                }
                if (image == '')
                {
                    $('#image').css('border', '1px solid red');
                    $('#prod_img_err').text('Please upload product image');
                    str = false;
                }
                if (image != '')
                {
                    var ext = image.match(/\.(.+)$/)[1];
                    validformat = '';
                    switch (ext)
                    {
                        case 'jpg':
                        case 'jpeg':
                        case 'bmp':
                        case 'png':
                        case 'tif':
                            validformat = true;
                            break;
                        default:
                            validformat = false;
                    }
                    if (validformat == false)
                    {
                        $('#imgae').css('border', '1px solid red');
                        $('#prod_img_err').text('Upload valid jpeg,jpg,png,bmp,tif images only');
                        str = false;
                    }
                }
                if (str == true) {
                    $('#btn_submit').hide();
                    $.ajax({
                        dataType: 'JSON',
                        method: 'POST',
                        data: new FormData(this),
                        url: "<?php echo base_url(); ?>superadmin/Category/insertProduct",
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data) {
                            console.log(data);
                            switch (data.code)
                            {
                                case 200:

                                    $('.success_msg').html(data.description).addClass('alert alert-success fade in');
                                    setTimeout(function () {
                                        window.location = "<?php echo base_url(); ?>superadmin/Category/manageproducts";
                                    }, 3000);
                                    break;
                                case 204:
                                    $('.fail_msg').html(data.description).addClass('alert alert-success fade in');
                                    $('#btn_submit').show();
                                    setTimeout(function () {
                                        window.location = "<?php echo base_url(); ?>superadmin/Category/createproduct";
                                    }, 3000);
                                case 301:
                                case 422:
                                case 575:
                                    $('.success_msg').html(data.description).addClass('alert alert-danger fade in');
//                                            $('.form_loading_hide').show();
//                                            $('.form_loading_show').hide();
                                    break;
                            }
                        },
                        error: function (error) {
                            console.log(error);
                        },
                    });
                }
            });

        </script>
        <script type="text/javascript">
            $('.pricefilter').on('keyup', function () {
                $(this).css('border', '');
                var pricevalue = $(this).val();
                if (isNaN(pricevalue) || pricevalue == 0)
                {
                    $(this).css('border', '1px solid red').val('');
                }
            });
            $('#menu_id').on('change', function () {
                var menu = $(this).val();
                if (menu > 0 && !isNaN(menu)) {
                    $('#submenu_id').html('');
                    $.ajax({
                        dataType: 'html',
                        method: 'POST',
                        data: {'menu': menu, 'submenuid': 'submenuid'},
                        url: '<?php echo base_url(); ?>superadmin/Category/submenuWithMenu',
                        success: function (ss) {
                            console.log(ss);
                            $('#submenu_id').html(ss);
                        },
                        error: function (se) {
                            console.log(se);
                        }
                    });
                }
            });
            $('#submenu_id').on('change', function () {
                var submenu = $(this).val();
                if (submenu > 0 && !isNaN(submenu)) {
                    $('#listsubmenu').html('');
                    $.ajax({
                        dataType: 'html',
                        method: 'POST',
                        data: {'submenu': submenu},
                        url: '<?php echo base_url(); ?>Superadmin/Category/listSubMenuWithMenu',
                        success: function (ss) {
                            $('#listsubmenu').html(ss);
                        },
                        error: function (se) {
                            console.log(se);
                        }
                    });
                }
            });
        </script>
    </body>
</html>