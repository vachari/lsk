
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Login </title>
	<link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />
	<style type="text/css"> 
		body{
			background-color:#dea800;
		}
		.mid{
			
			margin:0 auto;
		}
		
	</style>
</head>
<body>
	
	<div class="container-fluid" > 
		<div class="container"> 
			<img src="<?php echo SUPER_IMG_PATH;?>logo.png" alt="" style="background-color: #dea800;width:18%;margin-left:220px;margin-top:0px;" /> 
			<div class="col-md-3  mid" style="background-color:#eee;border-radius:9px;top:120px;left:40%;"> 
				
				<h2 style="color:#227bff">Super Admin </h2><br>
				<?php $attributes = array('id' => 'register-form');
					echo form_open('superadmin/Category/login',$attributes); ?>
					<?php 
				if(!empty($msg))
					{
						echo "<div class='alert alert-danger'>".$msg."</div>"; 
					}
				if(!empty($result))
					{
						echo "<div class='alert alert-success'>".$result."</div>"; 
					}
				

			 ?>
			 <?php if($this->session->flashdata('error')){
			 		echo "<div class='alert alert-danger'>".$this->session->flashdata('error')."</div>"; 
						
					} ?>
					<div class=" form-group"> 
					<span> 
						<?php echo form_label('Email','Email'); ?>
						<?php 	echo  form_error('email'); ?>
					</span>	

						<?php
						        	$data = array(
											        'name'          => 'email',
											        'id'            => 'email',
											        'maxlength'     => '40',
											        'autocomplete'  => 'off',
											        'class'			=> 'form-control',
											        'placeholder'	=> 'Enter Your Email'

											);

						         echo form_input($data);?>
					</div>
					<div class=" form-group"> 
					
					<span>
						<?php echo form_label('Password','Password'); ?>
						<?php 	echo  form_error('password'); ?>
					</span>
					
						<?php
						        	$data = array(
											        'name'          => 'password',
											        'id'            => 'password',
											        'maxlength'     => '40',
											        'autocomplete'  => 'off',
											        'class'			=> 'form-control',
											        'placeholder'	=> 'Password'

											);

						         echo form_password($data);?>
					</div>
						
						<?php echo form_submit(array('name'=>'submit','value'=>'Login','class'=>'btn btn-md btn-block btn-success')); ?> <br>
						<!-- <span class="pull-left" ><input type="checkbox" name="remember" >  Remamber Me</span><br><br>
					<a href="dashboard.html"  class="btn btn-md btn-block btn-success"> Login </a><br> -->
				</form>
			</div>
		</div>
	</div>



 <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
 <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jkvalidate.js"></script>
 <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.validate.min.js"></script>
 <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>additional-methods.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>	
</body>
</html>