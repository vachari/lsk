<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Create Sub List Category </title><!-- 
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />
	
  </head>
  <body>
	<?php include('includes/header.php'); ?>
	<!-- content Starts  hear  -->	

		<div class="col-md-12"> 
			<ol class="breadcrumb breadcrumb-arrow">
				<li><a href="<?php echo base_url().'dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
				<li><a href="">Category</a></li>
				<li class="active"><span>Create Listsub Category </span></li>
			</ol>
		</div> 
	<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="" style="padding:15px">
					<h3> <b> Create Listsub Category </b></h3>
					
				</div>
				<div class="panel-body">
					<div class="col-md-12"> 
							<?php //print_r($menu_result);exit;?>
		                    <?php
		                    	$attributes = array('name' =>'form' ,'id'=> 'register-form');
		                    	 echo form_open_multipart('superadmin/Category/createlistsubCategory',$attributes); ?>
		                    	 <div class="form-group col-xs-4">
								<?php echo form_label('Choose Category ','Choose Category ')."<span style='color:red'>*".form_error('menu_id')."</span>"; ?>
								
						      
									
									<select name="menu_id" id="menu_id" class="form-control ">
										<option value=""> ------- Choose Category ------- </option>

									<?php 
										foreach($menu_result as $row){
									?>
										<option value="<?php echo $row->menu_id; ?>"><?php echo $row->menu_title; ?> </option>
									<?php
									}
									?>
									
									</select>
								</div>
								<div class="form-group col-xs-4">
								
								<?php echo form_label('Choose Sub Category','Choose Sub Category')."<span style='color:red'>*".form_error('submenu_id')."</span>";?>
						        
									<select name="submenu_id" id="submenu_id" class="form-control ">
										<option value=""> ------- Choose sub category ------- </option>

									<?php 
										foreach($submenu_result as $row){
									?>
				   					  <option value="<?php echo $row->submenu_id; ?>"><?php echo $row->submenu_title; ?> </option>
									<?php
									}
									?>
									
									</select>
								</div>
								<div class="clearfix"></div>
						        <div class="form-group col-xs-8">
						        	<?php echo form_label('Listsub Category Title','Listsub Category Title')."<span style='color:red'>*".form_error('listsubmenu_title')."</span>"; ?>
						        
						        	
						        	<?php
						        	$data = array(
											        'name'          => 'listsubmenu_title',
											        'id'            => 'menu_title',
											        'maxlength'     => '40',
											        'autocomplete'  => 'off',
											        'class'			=> 'form-control',
											        'placeholder'	=> 'Enter list Sub Category'

											);

						         echo form_input($data);?>
						         	
						        </div>
						        <div class="clearfix"> </div>
						        <div class="form-group col-xs-4"> 
						        	<?php echo form_label('IMAGE (250 X 150)','IMAGE '); ?>
						        <span style="color:red;"> *</span> 
						        	
						        	<?php
						        	$upload1 = array(
											        'name'          => 'image',
											        'id'            => 'image',
											        'class'			=> 'form-control'
											);

						         echo form_upload($upload1);?>
								</div>
								<div class="form-group col-xs-4"> 
						        	<?php echo form_label('App Icon (100 X 80)','App Icon'); ?>
						        <span style="color:red;"> *</span> 
						        	
						        	<?php
						        	$upload2 = array(
											        'name'          => 'icon',
											        'id'            => 'icon',
											        'class'			=> 'form-control'
											);

						         echo form_upload($upload2);?>
						        	
								</div>
								
								<div class="clearfix"> </div>
								<div class="form-group col-xs-8 pull-right"> 
								 <?php echo form_submit('submit','Submit',array('class'=>'btn btn-success','name'=>'btn_submit','id'=>'btn_submit')); ?>
						        	
						        	<a href="<?php echo base_url().'superadmin/Category/managelistsubCategory'; ?> " class="btn btn-primary btn-md	"> <i class="glyphicon glyphicon-eye-open"></i> View Sub List Menus</a>
								</div>
						        	
						        	
						    </form>
	                      <span class="help_block"></span>
	                </div>
				</div>
			</div>
		</div>
		<!-- content ends hear  -->				
    <?php include('includes/footer.php'); ?>	
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>additional-methods.min.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.validate.min.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.min.js"></script>
	 </body>
</html>

<script>
$(function(){
	 $.validator.setDefaults({
    errorClass: 'help-block',
    highlight: function(element) {
      $(element)
        .closest('.form-group')
        .addClass('has-error');
    },
    unhighlight: function(element) {
      $(element)
        .closest('.form-group')
        .removeClass('has-error');
    },
    errorPlacement: function (error, element) {
      if (element.prop('type') === 'checkbox') {
        error.insertAfter(element.parent());
      } else {
        error.insertAfter(element);
      }
    }
  });

  $.validator.addMethod('strongPassword', function(value, element) {
    return this.optional(element) 
      || value.length >= 6
      && /\d/.test(value)
      && /[a-z]/i.test(value);
  }, 'Your password must be at least 6 characters long and contain at least one number and one char\'.')

	$("#register-form").validate({
		rules:{
			//name fields

			menu_id:{
				required:true
				 
				
			},
			submenu_id:{
				required:true
				 
				
			},
			
			listsubmenu_title:{
				required:true
			}
			
			
			
		},
		messages:{
			required:'Please Enter Your Email',
			email:'please enter a valid email address'
		}
	});
	
});

            $('#menu_id').on('change', function () {
                var menu = $(this).val();
              
                if (menu > 0 && !isNaN(menu)) {
                    $('#submenu_id').html('');
                    $.ajax({
                        dataType: 'html',
                        method: 'POST',
                        data: {'menu': menu, 'submenuid': 'submenuid'},
                        url: '<?php echo base_url(); ?>superadmin/Category/submenuWithMenu',
                        success: function (ss) {
                            console.log(ss);
                            $('#submenu_id').html(ss);
                        },
                        error: function (se) {
                            console.log(se);
                        }
                    });
                }
            });
</script>
