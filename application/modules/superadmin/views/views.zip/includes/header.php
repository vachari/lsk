<div class="container-fluid " style="background-color:#4cae4c;color:#fff;"> 
		<div class="col-sm-10 "> 
			<span class="">  <a href="<?php echo base_url().'superadmin/dashboard'; ?>" style="text-decoration: none;color:#fff;">
            <h3> Garradhar Super Admin  <?php //echo $this->session->userdata('email'); ?></h3> </a>
				<a href="dashboard.html">
					<!-- <img src="images/logo.png" width="" class="img-responsive" style=""> -->
			    </a>
			</span>
		</div>
		
		<div class="col-sm-2  "  style="margin-top:15px;"> 
			<nav class="navbar-default "> 
                <button type="button" class="navbar-toggle collapsed" data-toggle="offcanvas" data-target="#slide-menu" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </nav>
			 <ul class="" style=""> 
                <li class="dropdow" style="list-style:none;">
					<a href="#" class="dropdown-toggle" style="color:#fff" data-toggle="dropdown">
						<i class="glyphicon glyphicon-lock" style="padding:7px;"></i> 
							<b class="caret" style="color:#fff;"></b>
					</a>
					<ul class="dropdown-menu" >
						<li style="margin-left:0px;padding:0px " >
							<a href="#"><i class="glyphicon glyphicon-user"></i> Profile</a>
						</li>
						<li style="margin-left:0px;padding:0px " >
							<a href="<?php echo base_url().'superadmin/changePassword/';?>"><i class="glyphicon glyphicon-cog"></i> Change Password</a>
						</li>
						<li style="margin-left:0px;padding:0px " >
							<a href="<?php echo base_url().'superadmin/Category/logout';?>"><i class="glyphicon glyphicon-log-out"></i> Log Out</a>
						</li>
					</ul>
				</li>
			</ul>
		</div>
		
	</div>
    <div class="container-fluid display-table">
        <div class="row display-table-row">

            <div class="col-md-2 hidden-xs col-sm-1 display-table-cell valign-top" id="slide-menu" ><!-- Slider menu -->
                

                <ul style="margin-top:21px;"> 
                    <li class="link active"> 
                        <a href="<?php echo base_url().'superadmin/dashboard'; ?>">
                            <span class="glyphicon glyphicon-home" aria-hidden="true"></span>
                            <span class="hidden-xs hidden-sm"> Dashboard </span>
                        </a>
                    </li>
                    
                    <li class="link"> 
                        <a href="#collapse-cat" data-toggle="collapse" aria-controls="collapse-cat">
                            <span class="glyphicon glyphicon-list"> </span>
                            <span class="hidden-xs hidden-sm"> Category  <b class="caret pull-right"></b></span>
                            <!-- <span class="label label-success pull-right hidden-xs hidden-sm "> 20</span> -->

                        </a>
                        <ul class="collapse collapseable" id="collapse-cat"> 
                            <li> <a href="<?php echo base_url().'superadmin/Category/createCategory'; ?> "> Create Category</a> </li>
                             <li> <a href="<?php echo base_url().'superadmin/Category/manageCategory/'; ?>"> Manage Category</a> </li>
                        </ul>
                    </li>
					<li class="link"> 
                        <a href="#collapse-sub" data-toggle="collapse" aria-controls="collapse-sub">
                            <span class="glyphicon glyphicon-align-center"> </span>
                            <span class="hidden-xs hidden-sm">Sub Category <b class="caret pull-right"></b></span>
                            <!-- <span class="label label-success pull-right hidden-xs hidden-sm "> 20</span> -->

                        </a>
                        <ul class="collapse collapseable" id="collapse-sub"> 
                            <li> <a href="<?php echo base_url().'superadmin/Category/createsubCategory/'; ?>  "> Create Sub Category </a> </li>
                             <li> <a href="<?php echo base_url().'superadmin/Category/managesubCategory'; ?>"> Manage Sub Category  </a> </li>
                        </ul>
                    </li>
                    <li class="link"> 
                        <a href="#collapse-list" data-toggle="collapse" aria-controls="collapse-list">
                            <span class="glyphicon glyphicon-align-right"> </span>
                            <span class="hidden-xs hidden-sm">Listsub Category <b class="caret pull-right"></b></span>
                            <!-- <span class="label label-success pull-right hidden-xs hidden-sm "> 20</span> -->

                        </a>
                        <ul class="collapse collapseable" id="collapse-list"> 
                            <li> <a href=" <?php echo base_url().'superadmin/Category/createlistsubCategory'; ?>"> Create Listsub Category </a> </li>
                             <li> <a href="<?php echo base_url().'superadmin/Category/managelistsubCategory/'; ?>"> Manage Listsub Category  </a> </li>
                        </ul>
                    </li>

                    <li class="link"> 
                        <a href="#collapse-products" data-toggle="collapse" aria-controls="collapse-products">
                            <span class="glyphicon glyphicon-tree-deciduous"> </span>
                            <span class="hidden-xs hidden-sm">Products<b class="caret pull-right"></b></span>
                            <!-- <span class="label label-success pull-right hidden-xs hidden-sm "> 20</span> -->

                        </a>
                        <ul class="collapse collapseable" id="collapse-products"> 
                            <li> <a href=" <?php echo base_url().'superadmin/Product/createproduct'; ?>"> Add Product </a> </li>
                             <li> <a href="<?php echo base_url().'superadmin/Product/productDetails/'; ?>"> Manage Products  </a> </li>
                             <li> <a href="<?php echo base_url().'superadmin/Product/prodStock/'; ?>"> Product Stocks  </a> </li>
                        </ul>
                    </li>
                    		<li class="link"> 
                        <a href="#collapse-units" data-toggle="collapse" aria-controls="collapse-units">
                            <span class="glyphicon glyphicon-cog"> </span>
                            <span class="hidden-xs hidden-sm">Product Settings <b class="caret pull-right"></b></span>
                            <!-- <span class="label label-success pull-right hidden-xs hidden-sm "> 20</span> -->

                        </a>
                        <ul class="collapse collapseable" id="collapse-units"> 
                            <li> <a href=" <?php echo base_url().'superadmin/Settings/createUnits'; ?>"> Create Product Units </a> </li>
                              <li> <a href=" <?php echo base_url().'superadmin/Settings/createGroups'; ?>"> Create Product Groups </a> </li>
                             <li> <a href="<?php echo base_url().'superadmin/Settings/manageUnits/'; ?>"> Manage Product Units  </a> </li>

                             <li> <a href="<?php echo base_url().'superadmin/Settings/manageGroups/'; ?>"> Manage Product Groups  </a> </li>
                             
                        </ul>
                    </li>
                    <li class="link"> 
                        <a href="#collapse-orders" data-toggle="collapse" aria-controls="collapse-orders">
                            <span class="glyphicon glyphicon-shopping-cart"> </span>
                            <span class="hidden-xs hidden-sm">Orders<b class="caret pull-right"></b></span>
                           <!--  <span class="label label-primary pull-right hidden-xs hidden-sm "> 20</span> -->

                        </a>
                        <ul class="collapse collapseable" id="collapse-orders"> 
                            <li> <a href=" <?php echo base_url().'superadmin/Category/orders'; ?>"> Orders View </a> </li>
                             <li> <a href="<?php echo base_url().'superadmin/Category/manageproducts/'; ?>"> </a> </li>
                        </ul>
                    </li>
                    <li class="link"> 
                        <a href="#collapse-slider" data-toggle="collapse" aria-controls="collapse-slider">
                            <span class="glyphicon glyphicon-picture"> </span>
                            <span class="hidden-xs hidden-sm">Sliders<b class="caret pull-right"></b></span>
                            <!-- <span class="label label-success pull-right hidden-xs hidden-sm "> 20</span> -->

                        </a>
                        <ul class="collapse collapseable" id="collapse-slider"> 
                            <li> <a href=" <?php echo base_url().'superadmin/Category/createslider'; ?>"> Create Slider </a> </li>
                             <li> <a href="<?php echo base_url().'superadmin/Category/manageslider/'; ?>"> Manage Sliders  </a> </li>
                        </ul>
                    </li>
					<!-- <li class="link"> 
                        <a href="#" data-toggle="collapse" aria-controls="">
                            <span class="glyphicon glyphicon-book"> </span>
                            <span class="hidden-xs hidden-sm"> Bookings  </span>
                          <span class="label label-success pull-right hidden-xs hidden-sm "> 20</span>
                        </a>
                        
                    </li> -->
                    <li class="link"> 
                        <a href="#collapse-faq" data-toggle="collapse" aria-controls="collapse-faq">
                            <span class="glyphicon glyphicon-picture"> </span>
                            <span class="hidden-xs hidden-sm">FAQ's<b class="caret pull-right"></b></span>
                            <!-- <span class="label label-success pull-right hidden-xs hidden-sm "> 20</span> -->

                        </a>
                        <ul class="collapse collapseable" id="collapse-faq"> 
                            <li> <a href="<?php echo base_url(); ?>superadmin/Faqs/createFaq"> Create FAQ's </a> </li>
                             <li> <a href="<?php echo base_url(); ?>superadmin/Faqs"> Manage FAQ's  </a> </li>
                        </ul>
                    </li>
								
                    <!-- <li class="link settings-btn"> 
                        <a href="settings.html">
                            <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                            <span class="hidden-xs hidden-sm">  </span>
                        </a>
                    </li> -->
                    <br>
                </ul>
				<br>
            </div>
            <div class="col-md-10 col-sm-11 box display-table-cell valign-top" ><!-- Content menu --><br> 