<!-- footer starts he1zar  -->
                <div class="row"  > 
                    <footer id="admin-footer" class="clearfix"> 
                        <div class="pull-left"> <b>Copyright Gharaadhar © 2017 </b></div>
                        <div class="pull-right"> Design & developed by : <a href="http://richlabz.com"> Richlabz IT Solutions Pvt Ltd. </a></div>
                    </footer>
                </div>
            </div>
        </div>
    </div>  
	 <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.validate.min.js"></script>
 <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>additional-methods.min.js"></script>