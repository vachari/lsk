<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Super Admin </title><!-- 
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />
	
  </head>
  <body>
		<?php include('includes/header.php'); ?>
            	<div class="col-md-12"> 
					<ol class="breadcrumb breadcrumb-arrow">
						<li><a href="<?php echo base_url().'superadmin/dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
						<li><a href=""><?php echo $this->uri->segment(3); ?></a></li>
						<li class="active"><span>Manage Orders </span></li>
					</ol>
				</div> 
				
					<div class="col-md-12">
							
							<div class="panel panel-default">
								<!-- <div class="col-md-12"> 
									<ol class="breadcrumb breadcrumb-arrow">
										<li><a href="dashboard.html"><i class="glyphicon glyphicon-th" aria-hidden="true"></i> Dashboard</a></li>
										<li><a href="">Hostel Owners</a></li>
										<li class="active"><span>Manage All Hostels</span></li>
									</ol>
								</div>  -->
								<div class="" style="padding:15px">
									<h3> <b> Manage Orders	 </b></h3>
								</div>
								
								<!-- /.panel-heading -->
								<div class="panel-body">
									<div class="col-md-12"> 
										<table width="100%" class="table " id="">
										<thead>
											
											<tr>
												<td> 
													<div class="input-group">
													  
													  <input type="text" class="form-control" placeholder="Search for...">
													  <span class="input-group-btn">
														<button class="btn btn-secoundary" type="button"><i class="glyphicon glyphicon-search"></i></button>
													  </span>
													</div>
												</td>
												<td> 
													<!-- <select name=" " id="" class="form-control">
														<option value=" "> --Select Your Option-- </option>
														<option value=" "> Option one </option>
														<option value=" "> Option two </option>
														<option value=" "> Option Three </option>
													
													</select> -->
												</td>
												<td> 
													<a href="" class="btn btn-sm btn-success "> <i class="glyphicon glyphicon-ok"></i> Active </a> 
													<a href="" class="btn btn-sm btn-warning "><i class="glyphicon glyphicon-ban-circle"></i>   In Active  </a> 
                                                    <a href="<?php echo site_url('superadmin/Category/createproduct'); ?>" class="btn btn-sm btn-primary " ><i class="glyphicon glyphicon-plus"></i>  Create New </a> 
                                                    <a href="" class="btn btn-sm btn-info "><i class="glyphicon glyphicon-sort-by-order"></i>  Set Priority </a> 
													<a href="" class="btn btn-sm btn-danger "><i class="glyphicon glyphicon-remove"></i>  Cancel Orders </a> 
												</td>
												
											</tr>
										</thead>
										
										</table>
									</div>
									<div class="col-md-12"> 
										<table class="table table-bordered"> 
											<tr>
												<th>
													<input type="checkbox" id="checkAll" >
												</th>
												
												<th> Sl.no </th>
												<th>Order#</th>
												<th>Payment Type</th>
												<th>Name </th>
												<th>Email</th>
												<th>Mobile</th>
												<th>City</th>
												<th> Qty</th>
												<th>Order Price</th>
												<th colspan="2" class="text-center">Action</th>
												
											</tr>
											<tr>
												<td>
													<input type="checkbox" id="checkAll" >
												</td>
												
												<td> 1 </td>
												<td>Ghar10110</td>
												<td>COD</td>
												<td>Dall </td>
												<td>ujk222@gmail.com</td>
												<td>9666544180</td>
												<td>Hyderabad</td>
												<td>3</td>
												<td>
													<b> Sub Total:</b> Rs.509 <br>
													<b>Shipping Charges:</b> Rs.79 <br>
													<b>Discount:</b>Rs.0 <br>
													<b>Total Price: </b>Rs.579
												</td>
												<td> <a href="<?php echo base_url().'superadmin/Category/orderdetails'; ?>" class="btn btn-sm btn-warning "> View Details  </a></td>
												<td><a href="" class="btn btn-sm btn-danger " onclick="return confirm('Are you sure?')"> Cancel Order </a></td>
												
											</tr>
				


										</table>

									</div>
								
									
						<div class="text-center"> 
								<nav aria-label="Page navigation">
								  <ul class="pagination">
								   	<li class="disabled"><a href="#" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a>
								   	</li>
    								<li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
								    <li><a href="#">2</a></li>
								    <li><a href="#">3</a></li>
								    <li><a href="#">4</a></li>
								    <li><a href="#">5</a></li>
								    <li>
								      <a href="#" aria-label="Next">
								        <span aria-hidden="true">&raquo;</span>
								      </a>
								    </li>
								  </ul>
								</nav>

						</div>
								</div>
								
								<!-- /.panel-body -->
							</div>
							<!-- /.panel -->
							
						</div>
						<!-- /.col-lg-12 -->
    			<?php include('includes/footer.php'); ?>	
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
  </body>
</html>
<script type="text/javascript">
	$("#checkAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});



</script>