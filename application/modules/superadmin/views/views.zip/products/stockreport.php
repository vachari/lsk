<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Create Product Stock</title><!-- 
            <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>default.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>jquery.datetimepicker.css"/>
    </head>
    <style>
        .err_class{color:red}
    </style>
    <body>
        <?php $this->load->view('includes/header'); ?>
        <!-- content Starts  hear  -->	

        <div class="col-md-12"> 
            <ol class="breadcrumb breadcrumb-arrow">
                <li><a href="<?php echo base_url() . 'dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
                <li><a href="">Products</a></li>
                <li class="active"><span>Create Product Stock</span></li>
            </ol>
        </div> 
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="" style="padding:15px">
                    <h3> <b> Create Product Stock</b></h3>
                    <?php if (validation_errors()) { ?>
                        <div class="alert alert-danger">
                            <?php echo validation_errors(); ?>
                        </div> 
                        <?php
                    }
                    ?>
                </div>
                <div class="panel-body">
                    <div class="col-md-12"> 

                        <?php
                        $form_attributes = array('id' => 'insertproduct', 'name' => 'insertproduct');
                        echo form_open('', $form_attributes);
                        ?>

                        <div class="form-group col-xs-4">
                            <?php echo form_label('Product Group', 'Product Group');
                            ?>
                            <span style="color:red;"> *</span> 
                            <select name="group_id" id="group_id" class="form-control ">
                                <option value="">Choose Group </option>
                                <?php
                                $group_req = json_decode($groups_result);
                                if ($group_req->code == SUCCESS_CODE) {
                                    foreach ($group_req->groups_list as $group_response) {
                                        ?>
                                        <option value="<?php echo $group_response->id; ?>"><?php echo $group_response->group_code; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                            <span class="err_class" id="group_err"></span>
                        </div>

                        <div class="form-group col-xs-4">
                            <?php echo form_label('Unit Of Measure', 'Unit Of Measure');
                            ?>
                            <span style="color:red;"> *</span> 
                            <select name="unit_id" id="unit_id" class="form-control ">
                                <option value="">Choose Unit </option>
                                <?php
                                $unit_req = json_decode($unit_result);
                                if ($unit_req->code == SUCCESS_CODE) {
                                    foreach ($unit_req->units_list as $units_response) {
                                        ?>
                                        <option value="<?php echo $units_response->id; ?>"><?php echo $units_response->unit_code; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                            <span class="err_class" id="unit_err"></span>
                        </div>
                        <div class="clearfix"></div>
                        <div class="clearfix"></div>
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data1 = array(
                            'name' => 'vendor',
                            'id' => 'vendor',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control',
                            'placeholder' => 'Vendor'
                        );
                        echo form_label('Vendor', 'Vendor')." <span style='color:red'> *</span>";
                        echo form_input($data1);
                        ?>
                        <span class="err_class" id="vendor_err"></span>
                        <?php
                        echo "</div>";
                        ?>


                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data2 = array(
                            'name' => 'truckload',
                            'id' => 'truckload',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Truck Load Quantity'
                        );
                        echo form_label('Truck Load Quantity', 'Truck Load Quantity') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="truckload_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <div class="clearfix"></div>
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data2 = array(
                            'name' => 'minorderqty',
                            'id' => 'minorderqty',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Min Order Qty'
                        );
                        echo form_label('Min Order Qty', 'Min Order Qty') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="mind_order_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data2 = array(
                            'name' => 'buying_price',
                            'id' => 'buying_price',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Buying Price/UOM',
                        );
                        echo form_label('Buying Price/UOM', 'Buying Price/UOM') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="buying_price_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <div class="clearfix"> </div>
                        <?php
                        echo "<div class='form-group col-md-4'> ";
                        $data2 = array(
                            'name' => 'ord_sku_prod_code',
                            'id' => 'ord_sku_prod_code',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control',
                            'placeholder' => 'Ordered Prod SKU Code'
                        );
                        echo form_label('Ordered Prod SKU Code', 'Ordered Prod SKU Code') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="sku_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <div class="clearfix"></div>
                        
                        <div class="form-group col-xs-8 pull-right"> 
                            <span class="success_msg" style="color:green;"></span></br>
                        <span class="fail_msg" style="color:red;"></span>
                        <br/><br/>
                            <?php echo form_submit('submit', 'Submit', array('class' => 'btn btn-success', 'name' => 'btn_submit', 'id' => 'btn_submit')); ?>

<!--                            <a href="<?php echo base_url() . 'superadmin/Category/manageproducts'; ?> " class="btn btn-primary btn-md	"> <i class="glyphicon glyphicon-eye-open"></i> View Product List</a>-->
                        </div>
                        <?php echo form_close(); ?>
                        <span class="help_block"></span>
                    </div>
                </div>
            </div>
        </div>
        <!-- content ends hear  -->				
        <?php $this->load->view('includes/footer'); ?>	
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
        <script src="<?php echo SUPER_JS_PATH; ?>jquery.datetimepicker.full.js"></script>
        <script>
            $.datetimepicker.setLocale('en');
            var currentTime = new Date();
            var extendDate = new Date(currentTime.getFullYear(), currentTime.getMonth() + 1, currentTime.getDate());
            $('#datetimepicker').datetimepicker({value: new Date(), minDate: new Date(), maxDate: extendDate, format: "d-m-Y H:i", minTime: '10', pickTime: false, timepicker: true, }).css({'color': '#000', 'background-color': '#F6FBFC'});
            $('.bookingdate_class').datetimepicker({
                minDate: new Date(), maxDate: extendDate, format: "d-m-Y H:i", minTime: '10', pickTime: false, timepicker: true,
            }).css({'color': '#000', 'background-color': '#F6FBFC'});
            //$('#datetimepicker').timepicker( 'option', 'hours', {starts: 05, ends: 23});

        </script>
        <script type="text/javascript">
            $('#insertproduct').on('submit', function (i) {
                i.preventDefault();
                var str = true;
                $('#sku_err,#buying_price_err,#mind_order_err,#truckload_err,#vendor_err,#group_err,#unit_err').html('');
                $('#group_id,#unit_id,#vendor,#truckload,#minorderqty,#buying_price,#ord_sku_prod_code').css('border', '');
                var vendor = $('#vendor').val();
                var truckload = $('#truckload').val();
                var minorderqty = $('#minorderqty').val();
                var buying_price = $('#buying_price').val();
                var unit = $('#unit_id').val();
                var group = $('#group_id').val();
                var order_prod_sku = $('#ord_sku_prod_code').val();
                if (unit == '') {
                    $('#unit_err').html('Please select unit');
                    $('#unit_id').css('border', '1px solid red');
                    str = false;
                }
                if (group == '') {
                    $('#group_err').html('Please select group');
                    $('#group_id').css('border', '1px solid red');
                    str = false;
                }
                if (vendor == '') {
                    $('#vendor_err').html('Please enter vendor');
                    $('#vendor').css('border', '1px solid red');
                    str = false;
                }
                if (truckload == '') {
                    $('#truckload_err').html('Please enter truck load');
                    $('#truckload').css('border', '1px solid red');
                    str = false;
                }
                if (minorderqty == '') {
                    $('#mind_order_err').html('Please enter min order qty');
                    $('#minorderqty').css('border', '1px solid red');
                    str = false;
                }
                if (buying_price == '') {
                    $('#buying_price_err').html('Please enter buying price');
                    $('#buying_price').css('border', '1px solid red');
                    str = false;
                }
                if (order_prod_sku == '') {
                    $('#sku_err').html('Please enter ordered product sku');
                    $('#order_prod_sku').css('border', '1px solid red');
                    str = false;
                }
                if (str == true) {
                    $('#btn_submit').hide();
                    $.ajax({
                        dataType: 'JSON',
                        method: 'POST',
                        data: new FormData(this),
                        url: "<?php echo base_url(); ?>superadmin/Product/insertProductStock",
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function (data) {
                            console.log(data);
                            switch (data.code)
                            {
                                case 200:

                                    $('.success_msg').html(data.description).addClass('alert alert-success fade in');
                                    setTimeout(function () {
                                        window.location = "<?php echo base_url(); ?>superadmin/Product/prodStock/";
                                    }, 3000);
                                    break;
                                case 204:
                                    $('.fail_msg').html(data.description).addClass('alert alert-success fade in');
                                    $('#btn_submit').show();
                                    setTimeout(function () {
                                        window.location = "<?php echo base_url(); ?>superadmin/Product/prodStock";
                                    }, 3000);
                                case 301:
                                case 422:
                                case 575:
                                    $('.success_msg').html(data.description).addClass('alert alert-danger fade in');
//                                            $('.form_loading_hide').show();
//                                            $('.form_loading_show').hide();
                                    break;
                            }
                        },
                        error: function (error) {
                            console.log(error);
                        },
                    });
                }
            });

        </script>
        <script type="text/javascript">
            $('.pricefilter').on('keyup', function () {
                $(this).css('border', '');
                var pricevalue = $(this).val();
                if (isNaN(pricevalue) || pricevalue == 0)
                {
                    $(this).css('border', '1px solid red').val('');
                }
            });
            $('#menu_id').on('change', function () {
                var menu = $(this).val();
                if (menu > 0 && !isNaN(menu)) {
                    $('#submenu_id').html('');
                    $.ajax({
                        dataType: 'html',
                        method: 'POST',
                        data: {'menu': menu, 'submenuid': 'submenuid'},
                        url: '<?php echo base_url(); ?>superadmin/Category/submenuWithMenu',
                        success: function (ss) {
                            console.log(ss);
                            $('#submenu_id').html(ss);
                        },
                        error: function (se) {
                            console.log(se);
                        }
                    });
                }
            });
            $('#submenu_id').on('change', function () {
                var submenu = $(this).val();
                if (submenu > 0 && !isNaN(submenu)) {
                    $('#listsubmenu').html('');
                    $.ajax({
                        dataType: 'html',
                        method: 'POST',
                        data: {'submenu': submenu},
                        url: '<?php echo base_url(); ?>Superadmin/Category/listSubMenuWithMenu',
                        success: function (ss) {
                            $('#listsubmenu').html(ss);
                        },
                        error: function (se) {
                            console.log(se);
                        }
                    });
                }
            });
        </script>
    </body>
</html>