<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Create Product Pricing </title><!-- 
            <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>default.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>jquery.datetimepicker.css"/>
    </head>
    <style>
        .err_class{color:red}
    </style>
    <body>
        <?php $this->load->view('includes/header'); ?>
        <!-- content Starts  hear  -->	

        <div class="col-md-12"> 
            <ol class="breadcrumb breadcrumb-arrow">
                <li><a href="<?php echo base_url() . 'dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
                <li><a href="">Products</a></li>
                <li class="active"><span>Create Product Pricing</span></li>
            </ol>
        </div> 
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="" style="padding:15px">
                    <h3> <b> Create Product Pricing </b></h3>
                    <h3 style="text-align: center;background: #4cae4c;color:white">Product Group Pricing</h3>
                    <?php if (validation_errors()) { ?>
                        <div class="alert alert-danger">
                            <?php echo validation_errors(); ?>
                        </div> 
                        <?php
                    }
                    ?>
                </div>
                <div class="panel-body">
                    <?php
                    $form_attributes = array('id' => 'insertproductprices', 'name' => 'insertproductprices');
                    echo form_open('', $form_attributes);
                    ?>
                    <input type="hidden" value="<?php echo $prod_id; ?>" name="prod_id" id="prod_id"/>
                    <div class="col-md-12 input_fields_wrap"> 
                        <?php
                        echo "<div class='form-group col-md-2'> ";
                        $data2 = array(
                            'name' => 'group_code[]',
                            'id' => 'group_code',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control',
                            'placeholder' => 'Group Code',
                            'value' => $group_code,
                            'readonly' => 'readonly',
                        );
                        echo form_label('Product Group', 'Product Group') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="prod_group_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <div class="form-group col-xs-2">
                            <?php echo form_label('Unit Of Measure', 'Unit Of Measure');
                            ?>
                            <span style="color:red;"> *</span> 
                            <select name="unit_id[]" id="unit_id" class="form-control ">
                                <option value="">Choose Unit </option>
                                <?php
                                $unit_req = json_decode($unit_result);
                                if ($unit_req->code == SUCCESS_CODE) {
                                    foreach ($unit_req->units_list as $units_response) {
                                        ?>
                                        <option value="<?php echo $units_response->id; ?>"><?php echo $units_response->unit_code; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                            <span class="err_class" id="unit_err"></span>
                        </div>
                        <?php
                        echo "<div class='form-group col-md-2'> ";
                        $data2 = array(
                            'name' => 'qty_range_from[]',
                            'id' => 'qty_range_from',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Quantity Range From'
                        );
                        echo form_label('Qty Range From', 'Qty Range From') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="qty_from_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <?php
                        echo "<div class='form-group col-md-2'> ";
                        $data2 = array(
                            'name' => 'qty_range_to[]',
                            'id' => 'qty_range_to',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Quantity Range To'
                        );
                        echo form_label('Qty Range To', 'Qty Range To') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="qty_to_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <?php
                        echo "<div class='form-group col-md-2'> ";
                        $data2 = array(
                            'name' => 'selling_price[]',
                            'id' => 'selling_price',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Selling Price'
                        );
                        echo form_label('Selling Price', 'Selling Price') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="sp_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <div class='form-group col-md-2'>
                            <button class='add_field_button btn btn-sm btn-warning'><i class="glyphicon glyphicon-plus"></i></button></br>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                    <h3 style="text-align: center;background: #4cae4c;color:white">Product Item Pricing</h3>
                    <div class="col-md-12 input_fields_wrap1"> 
                        <?php
                        echo "<div class='form-group col-md-2'> ";
                        $data2 = array(
                            'name' => 'prod_code[]',
                            'id' => 'prod_code',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control',
                            'placeholder' => 'Product Code',
                            'value' => $prod_code,
                            'readonly' => 'readonly',
                        );
                        echo form_label('Product Code', 'Product Code') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="prod_item_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <div class="form-group col-xs-2">
                            <?php echo form_label('Unit Of Measure', 'Unit Of Measure');
                            ?>
                            <span style="color:red;"> *</span> 
                            <select name="item_unit_id[]" id="item_unit_id" class="form-control ">
                                <option value="">Choose Unit </option>
                                <?php
                                $unit_req = json_decode($unit_result);
                                if ($unit_req->code == SUCCESS_CODE) {
                                    foreach ($unit_req->units_list as $units_response) {
                                        ?>
                                        <option value="<?php echo $units_response->id; ?>"><?php echo $units_response->unit_code; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                            <span class="err_class" id="item_unit_err"></span>
                        </div>
                        <?php
                        echo "<div class='form-group col-md-2'> ";
                        $data2 = array(
                            'name' => 'item_qty_range_from[]',
                            'id' => 'item_qty_range_from',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Item Quantity Range From'
                        );
                        echo form_label('Qty Range From', 'Qty Range From') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="item_qty_from_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <?php
                        echo "<div class='form-group col-md-2'> ";
                        $data2 = array(
                            'name' => 'item_qty_range_to[]',
                            'id' => 'item_qty_range_to',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Item Quantity Range To'
                        );
                        echo form_label('Qty Range To', 'Qty Range To') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="item_qty_to_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <?php
                        echo "<div class='form-group col-md-2'> ";
                        $data2 = array(
                            'name' => 'item_selling_price[]',
                            'id' => 'item_selling_price',
                            'maxlength' => '40',
                            'autocomplete' => 'off',
                            'class' => 'form-control pricefilter',
                            'placeholder' => 'Item Selling Price'
                        );
                        echo form_label('Selling Price', 'Selling Price') . "<span style='color:red'> *</span>";
                        echo form_input($data2);
                        ?>
                        <span class="err_class" id="item_sp_err"></span>
                        <?php
                        echo "</div>";
                        ?>
                        <div class='form-group col-md-2'>
                            <button class='add_field_button1 btn btn-sm btn-warning'><i class="glyphicon glyphicon-plus"></i></button></br>
                        </div>
                        <div class="clearfix"></div>
                    </div>

                    <div class="form-group col-xs-8 pull-right"> 
                        <span class="success_msg" style="color:green;" style="display:none;"></span></br>
                        <span class="fail_msg" style="color:red;" style="display:none;"></span><br/>
                        <div class="clearfix"></div>
                        <?php echo form_submit('submit', 'Submit', array('class' => 'btn btn-success', 'name' => 'btn_submit', 'id' => 'btn_submit')); ?>

                        <a href="<?php echo base_url() . 'superadmin/Product/productDetails'; ?> " class="btn btn-primary btn-md	"> <i class="glyphicon glyphicon-eye-open"></i> View Product List</a>
                    </div>
                    <?php echo form_close(); ?>
                    <span class="help_block"></span>

                </div>
            </div>
        </div>
    </div>
    <!-- content ends hear  -->				
    <?php $this->load->view('includes/footer'); ?>	
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
    <script src="<?php echo SUPER_JS_PATH; ?>jquery.datetimepicker.full.js"></script>
    <script>
        $.datetimepicker.setLocale('en');
        var currentTime = new Date();
        var extendDate = new Date(currentTime.getFullYear(), currentTime.getMonth() + 1, currentTime.getDate());
        $('#datetimepicker').datetimepicker({value: new Date(), minDate: new Date(), maxDate: extendDate, format: "d-m-Y H:i", minTime: '10', pickTime: false, timepicker: true, }).css({'color': '#000', 'background-color': '#F6FBFC'});
        $('.daterange_class').datetimepicker({
            minDate: new Date(), maxDate: extendDate, format: "d-m-Y H:i", minTime: '10', pickTime: false, timepicker: true,
        }).css({'color': '#000', 'background-color': '#F6FBFC'});
        //$('#datetimepicker').timepicker( 'option', 'hours', {starts: 05, ends: 23});

        $(document).ready(function () {
            var max_fields = 10; //maximum input boxes allowed
            var wrapper = $(".input_fields_wrap"); //Fields wrapper
            var add_button = $(".add_field_button"); //Add button ID

            var x = 1; //initlal text box count
            $(add_button).click(function (e) { //on add input button click
                e.preventDefault();
                if (x < max_fields) { //max input box allowed
                    x++; //text box increment
                    $(wrapper).append('<div><div class="form-group col-md-2"> <label for="Product Group">Product Group</label><span style="color:red"> *</span><input type="text" readonly value="<?php echo $group_code; ?>" name="group_code[]" value="" id="group_code" maxlength="40" autocomplete="off" class="form-control" placeholder="Group Code"><span class="err_class" id="prod_group_err"></span></div><div class="form-group col-xs-2"><label for="Unit Of Measure">Unit Of Measure</label><span style="color:red;"> *</span><select name="unit_id[]" id="unit_id" class="form-control "><option value="">Choose Unit </option><?php
    $unit_req = json_decode($unit_result);
    if ($unit_req->code == SUCCESS_CODE) {
        foreach ($unit_req->units_list as $units_response) {
            ?><option value="<?php echo $units_response->id; ?>"><?php echo $units_response->unit_code; ?></option><?php
        }
    }
    ?></select><span class="err_class" id="unit_err"></span></div><div class="form-group col-md-2"> <label for="Qty Range From">Qty Range From</label><span style="color:red"> *</span><input type="text" name="qty_range_from[]" value="" id="qty_range_from" maxlength="40" autocomplete="off" class="form-control pricefilter" placeholder="Quantity Range From"><span class="err_class" id="qty_from_err"></span></div><div class="form-group col-md-2"> <label for="Qty Range To">Qty Range To</label><span style="color:red"> *</span><input type="text" name="qty_range_to[]" value="" id="qty_range_to" maxlength="40" autocomplete="off" class="form-control pricefilter" placeholder="Quantity Range To"><span class="err_class" id="qty_to_err"></span></div><div class="form-group col-md-2"> <label for="Selling Price">Selling Price</label><span style="color:red"> *</span><input type="text" name="selling_price[]" value="" id="selling_price" maxlength="40" autocomplete="off" class="form-control pricefilter" placeholder="Selling Price"><span class="err_class" id="sp_err"></span></div><a href="#" class="remove_field  btn btn-sm btn-danger"><i class="glyphicon glyphicon-remove"></i></a></div><div class="clearfix"></div>'); //add input box
                }
            });

            $(wrapper).on("click", ".remove_field", function (e) { //user click on remove text
                e.preventDefault();
                $(this).parent('div').remove();
                x--;
            })
        });

        $(document).ready(function () {
            var max_fields = 10; //maximum input boxes allowed
            var wrapper = $(".input_fields_wrap1"); //Fields wrapper
            var add_button = $(".add_field_button1"); //Add button ID

            var x = 1; //initlal text box count
            $(add_button).click(function (e) { //on add input button click
                e.preventDefault();
                if (x < max_fields) { //max input box allowed
                    x++; //text box increment
                    $(wrapper).append('<div><div class="form-group col-md-2"> <label for="Product Group">Product Group</label><span style="color:red"> *</span><input readonly type="text" name="prod_code[]" value="<?php echo $prod_code; ?>" id="prod_code" maxlength="40" autocomplete="off" class="form-control" placeholder="Product Code"><span class="err_class" id="prod_item_err"></span></div><div class="form-group col-xs-2"><label for="Unit Of Measure">Unit Of Measure</label><span style="color:red;"> *</span><select name="item_unit_id[]" id="item_unit_id" class="form-control "><option value="">Choose Unit </option> <?php
    $unit_req = json_decode($unit_result);
    if ($unit_req->code == SUCCESS_CODE) {
        foreach ($unit_req->units_list as $units_response) {
            ?><option value="<?php echo $units_response->id; ?>"><?php echo $units_response->unit_code; ?></option><?php
        }
    }
    ?></select><span class="err_class" id="item_unit_err"></span></div><div class="form-group col-md-2"> <label for="Qty Range From">Qty Range From</label><span style="color:red"> *</span><input type="text" name="item_qty_range_from[]" value="" id="item_qty_range_from" maxlength="40" autocomplete="off" class="form-control pricefilter" placeholder="Quantity Range From"><span class="err_class" id="qty_from_err"></span></div><div class="form-group col-md-2"> <label for="Qty Range To">Qty Range To</label><span style="color:red"> *</span><input type="text" name="item_qty_range_to[]" value="" id="item_qty_range_to" maxlength="40" autocomplete="off" class="form-control pricefilter" placeholder="Quantity Range To"><span class="err_class" id="item_qty_to_err"></span></div><div class="form-group col-md-2"> <label for="Selling Price">Selling Price</label><span style="color:red"> *</span><input type="text" name="item_selling_price[]" value="" id="item_selling_price" maxlength="40" autocomplete="off" class="form-control pricefilter" placeholder="Selling Price"><span class="err_class" id="item_sp_err"></span></div><a href="#" class="remove_field  btn btn-sm btn-danger"><i class="glyphicon glyphicon-remove"></i></a></div><div class="clearfix"></div>'); //add input box
                }
            });

            $(wrapper).on("click", ".remove_field", function (e) { //user click on remove text
                e.preventDefault();
                $(this).parent('div').remove();
                x--;
            })
        });
        /*code for product pricing insert*/
        $('#insertproductprices').on('submit', function (i) {
            $('.fail_msg').hide();
            $('.success_msg').hide();
            $('#btn_submit').hide()
            i.preventDefault();
            $.ajax({
                dataType: 'JSON',
                method: 'POST',
                data: new FormData(this),
                url: "<?php echo base_url(); ?>superadmin/Product/insertProductPricing",
                contentType: false,
                cache: false,
                processData: false,
                success: function (data) {
                    console.log(data);
                    switch (data.code)
                    {
                        case 200:
                            $('.success_msg').show();

                            $('.success_msg').html(data.description).addClass('alert alert-success fade in');
                            setTimeout(function () {
                                window.location = "<?php echo base_url(); ?>superadmin/Product/productDetails";
                            }, 3000);
                            break;
                        case 204:
                            $('.fail_msg').show();
                            $('.fail_msg').html(data.description).addClass('alert alert-danger fade in');
                            $('#btn_submit').show();
                            setTimeout(function () {
                                window.location = "<?php echo base_url(); ?>superadmin/Product/productPricing";
                            }, 3000);
                        case 301:
                        case 422:
                        case 575:
                            $('.success_msg').show();
                            $('.success_msg').html(data.description).addClass('alert alert-danger fade in');
//                                            $('.form_loading_hide').show();
//                                            $('.form_loading_show').hide();
                            break;
                    }
                },
                error: function (error) {
                    console.log(error);
                },
            });
        });
    </script>