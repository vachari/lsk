<!DOCTYPE html>
<html lang="en">
  <head>
     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $URL_TITLE; ?></title><!-- 
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />
    <style>
        .pages a,.pages strong{                
            border: 1px solid #ddd;
            border-radius: 9px 9px;
            padding: 7px 12px;
         }
        .pages a{
             background-color: #c52825;
             border-radius:50px;
             color: white;
        }
    </style>
  </head>
  <body>
    <!-- Header -->
   <?php $this->load->view('includes/header'); ?> 
    <?php
    $faq_req=json_decode($common_result);
    //print_r( $faq_req->common_result);exit;
    ?>
    <div class="container-fluid display-table">
        <div class="row display-table-row">
                <div class="col-md-10 col-sm-11 box display-table-cell valign-top" ><!-- Content menu --><br>
                <?php if($this->session->flashdata('success')) { ?>
                <div class="alert alert-success" id="temp">
                <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                <?php if($this->session->flashdata('failure')) { ?>
                <div class="alert alert-danger" id="temp">
                <?php echo $this->session->flashdata('failure'); ?>
                </div>
                <?php } ?>
                <!--displaying breadcrumb-->
                <div class="col-md-12"> 
                    <ol class="breadcrumb breadcrumb-arrow">
                    <?php 
                    $breadcrumb_details = json_decode($breadcrumb);
                                $breadcrumb_count = count($breadcrumb_details);
                                foreach ($breadcrumb_details as $breadcrumb) {
                                //print_r($breadcrumb);
                                    ?>
                        <li class="<?php echo $breadcrumb->class; ?>"><a href="<?php echo $breadcrumb->link; ?>" <?php if(!empty($breadcrumb->class)){?>style='color:red;'<?php } ?>> <?php echo $breadcrumb->title; ?></a></li>
                       <?php }  ?>
                    </ol>
                </div>
                <!--displaying breadcrumb-->
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <!-- /.table-responsive -->
                                <div class="well">
                                    <h4 class="text-center"> <u> <?php echo $PAGE_TITLE; ?></u> </h4>
                                </div>
                                
                                <?php if(isset($not_selected)) { ?>
                                <div class="alert alert-danger" id="temp">
                                <?php echo $not_selected; ?>
                                </div>
                                <?php } ?>
                               <!--  <center><div id="failmessage"></div></center> -->
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    
                                        <form name="searchform" id="searchform" action="<?php echo SUPER_ADMIN_FOLDER_PATH; ?>Faqs" method="post" enctype="multipart/form-data">
                                                <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">
                                                    <div class="input-group">
                                                      <input type="text" class="form-control" name="search_name" id="search_name" placeholder="Search" aria-describedby="basic-addon2"  maxlength="120" autocomplete="off" >
                                                      <span class="input-group-addon" id="basic-addon2" ><i class="fa fa-search" aria-hidden="true"></i></span>
                                                    </div>
                                                    <div class="clearfix">&nbsp;</div>
                                                    <span id="searcherror" style="color:red;"></span>
                                                </div>
                                                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
                                                    <input type="submit" name="submit" id="submit" value="Search"  class="btn btn-success btn-md" /> 
                                                </div>
                                        </form>
                                    <table>
                                    <td>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                                            <button class="btn btn-success " style="margin-bottom:5px;" onclick="updateActivationStatus('1')" ><i class="fa fa-check" aria-hidden="true"></i>&nbsp;Active</button>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                                            <button class="btn btn-warning btn-md" style="margin-bottom:5px;" onclick="updateActivationStatus('0')"><i class="fa fa-ban" aria-hidden="true"></i>&nbsp;In active</button>
                                        </div>&nbsp;
                                    </td>
                                    <td>  
                                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2" onclick="return confirm('Confirm to delete')">
                                            <?php echo form_open(''); ?>
                                            <!-- <?php echo form_submit('submit','Delete',array('class'=>'btn btn-danger btn-md','style'=>'margin-bottom:5px;margin-left:18px','onclick'=>'return ConfirmDelete()')); ?> -->    
                                        </div>
                                    </td>
                                    
                                    </table>
                                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th> <input type="checkbox" class="inline-checkbox" name="multiAction" id="multiAction"> Select </th>
                                            <th> FAQ# </th>
                                            <th> Query </th>
                                            <th> Description </th>
                                            <th> Query Date</th>
                                            <th> Staus</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($faq_req->code==200){
                                        $sno=1;
                                        foreach($faq_req->common_result as $owners_response){
                                        ?>
                                         <tr class="gradeX">
                                            <td> <input type="checkbox" class="inline-checkbox" name="multiple[]" id="checkbox[]" value="<?php echo $owners_response->id; ?>">
                                            </td>
                                            <td><?php echo $owners_response->ref_no; ?></td>
                                            <td><?php echo $owners_response->query; ?></td>
                                            <td><?php echo $owners_response->description; ?></td>
                                            <td><?php echo $owners_response->qry_date; ?></td>
                                            <td><?php  
                                            if($owners_response->status!=1){
                                                ?>
                                                <span style="color: red"><b><?php echo "Not active"; ?></b></span>
                                                <?php
                                            }
                                            else{
                                                ?>
                                                <span style="color: green"><b><?php echo "Active"; ?></b></span>
                                                <?php
                                            }
                                            ?></td>
                                            
                                        </tr>
                                        <?php $sno++; } } else {  ?>
                                        <tr>
                                            <td colspan="4"><div class="alert alert-danger text-center text-upper"><?php echo $owners_req->description; ?></div></td>
                                        </tr>
                                            <?php } ?>
                                    </tbody>
                                </table>
                                <?php echo form_close(); ?>
                               <td colspan="4" > <p class="pages"><?php echo $links; ?></p></td>
                                <!-- /.table-responsive -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        
              
            </div>
            
        </div>
    <?php $this->load->view('includes/footer'); ?>
         
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>additional-methods.min"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.validate.min"></script>
  </body>
</html>
<SCRIPT language="javascript">
    /*>>checking multiple checkboxes code starts*/
    $("#multiAction").change(function () {
        $("input:checkbox").prop('checked', $(this).prop("checked"));
    });
    /*<<checking multiple checkboxes code ends*/
    /*>>Removing the messages after some time code starts*/
    $( document ).ready(function() {
        $("#temp").delay(1500).fadeOut("slow");
    });
    /*<<Removing the messages after some time code endss*/
    /*>>Confirm message before deleting a records/records*/
    function ConfirmDelete()
    {
        var x = confirm("Are you sure you want to delete?");
        if (x)
            return true;
        else
            return false;
    }
    /*>>Confirm message before deleting a records/records*/
    /*>>Changing owner status active/In-active code starts*/
    function updateActivationStatus(s) {
        var listarray = new Array();
        $('input[name="multiple[]"]:checked').each(function () {
         listarray.push($(this).val());
        });
        var checklist = "" + listarray;
        if (!isNaN(s) && (s == '1' || s == '0') && checklist != '') {
            $('#fail').hide();
            $.ajax({
                dataType: 'json',
                type: 'post',
                data: {'tablename': 'faqs', 'updatelist': checklist, 'activity': s},
                url: '<?php echo SUPER_ADMIN_FOLDER_PATH; ?>Screens/commonStatusActivity',
                success: function (u) {
                    //console.log(u);
                    if (u.code == '200') {
                        $('#success').show();
                        $('#successmessage').html(u.description);
                        setTimeout(function () {
                            window.location = location.href;
                        }, 2000);
                    }
                    if (u.code == '204' || u.code == '301' || u.code == '422') {
                        $('#fail').show();
                        $('#failmessage').html(u.description);
                    }
                },
                error: function (er) {
                    console.log(er);
                }
            });
        }
        else {
            $('#fail').show();
            $('#failmessage').html('*  Please select a record');
            //$('#failmessage').delay(1000).fadeOut();
        }
    }
    /*<<Changing owner status active/In-active code ends*/
</SCRIPT>
