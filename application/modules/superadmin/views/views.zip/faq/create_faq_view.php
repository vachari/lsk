<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $URL_TITLE; ?></title><!-- 
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />	
  </head>
  <body>
	  <?php $this->load->view('includes/header'); ?>
		<div class="col-md-12">   
			<ol class="breadcrumb breadcrumb-arrow">
				<?php 
                    $breadcrumb_details = json_decode($breadcrumb);
                                $breadcrumb_count = count($breadcrumb_details);
                                foreach ($breadcrumb_details as $breadcrumb) {
                                //print_r($breadcrumb);
                                    ?>
                        <li class="<?php echo $breadcrumb->class; ?>"><a href="<?php echo $breadcrumb->link; ?>" <?php if(!empty($breadcrumb->class)){?>style='color:red;'<?php } ?>> <?php echo $breadcrumb->title; ?></a></li>
                       <?php }  ?>
			</ol>
		</div> 
	<div class="col-lg-12">
	<?php if($this->session->flashdata('success')) { ?>
    <div class="alert alert-success" id="temp">
    <?php echo $this->session->flashdata('success'); ?>
    </div>
    <?php } ?>
    <?php if($this->session->flashdata('failure')) { ?>
    <div class="alert alert-danger" id="temp">
    <?php echo $this->session->flashdata('failure'); ?>
    </div>
    <?php } ?>
			<div class="panel panel-default ">
				<div class="panel-body" style=" width: 25%">
				<div class="">
                    <h3><?php echo $PAGE_TITLE; ?></h3>
                </div>
                <?php echo form_open(SUPER_ADMIN_FOLDER_PATH.'Faqs/insertFaq'); ?>
                <div class="form-group"> 
	                <label>Question<sup>*</sup></label><span id="span_question" class="error"><?php echo form_error('question'); ?></span>
	                <?php echo form_input(array('class'=>'form-control','name'=>'question','id'=>'question','placeholder'=>'Enter Question','value'=>set_value('question'),'autocomplete'=>'off')); ?>
	               </span>
	            </div>
	            <div class="form-group"> 
	                <label>Description<sup>*</sup></label><span id="span_description" class="error"><?php echo form_error('description'); ?></span>
	                <?php echo form_textarea(array('class'=>'form-control','name'=>'description','id'=>'description','placeholder'=>'Enter Description','value'=>set_value('description'),'autocomplete'=>'off')); ?>
	               </span>
	            </div>
	             <div class="form-group" > 
                    <?php echo form_submit('submit','Submit',array('class'=>'btn btn-success','name'=>'btn_submit','id'=>'btn_submit')); ?>
                </div> 
                <?php echo form_close(); ?>					
				</div>
			</div>
		</div>
		<!-- content ends hear  -->				
     <?php $this->load->view('includes/footer'); ?>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>additional-methods.min"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.validate.min"></script>
  </body>
</html>
<script>
$(function(){
	 $.validator.setDefaults({
    errorClass: 'help-block',
    highlight: function(element) {
      $(element)
        .closest('.form-group')
        .addClass('has-error');
    },
    unhighlight: function(element) {
      $(element)
        .closest('.form-group')
        .removeClass('has-error');
    },
    errorPlacement: function (error, element) {
      if (element.prop('type') === 'checkbox') {
        error.insertAfter(element.parent());
      } else {
        error.insertAfter(element);
      }
    }
  });
});
</script>
<script type="text/javascript">
     $( document ).ready(function() {
        $("#temp").delay(1500).fadeOut("slow");
        $("#btn_submit").click(function(){
            var str=true;
            var question=$('#question').val();
            var description=$('#description').val();
            $('#span_name,#span_email').html('');
            $('#question,#description').css('border','');
            var only_aplhabets_pattern=/^[a-zA-Z ]*$/;
            if(question=="" || question==" "){
                str=false;
                $('#question').css('border','1px solid red');
            }
            else if(!only_aplhabets_pattern.test(question)){
                    str=false;
                    $('#span_name').html(' Please enter valid question');
                    $('#question').css('border','1px solid red');
            }
            if(description=="" || description==" "){
                str=false;
                $('#description').css('border','1px solid red');
            }            
            return str;
            });
    });
    
</script>