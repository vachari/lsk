<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Update Product Groups | Settings </title><!-- 
            <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>default.css" />
        <style type="text/css">.mrtop{margin-top:10px;}</style>
    </head>
    <body>
        <?php $this->load->view('includes/header'); ?>
        <!-- content Starts  hear  -->	

        <div class="col-md-12"> 
            <ol class="breadcrumb breadcrumb-arrow">
                <li><a href="<?php echo base_url() . 'dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
                <li><a href="<?php  echo base_url().'superadmin/Settings/manageGroups'; ?>">Settings</a></li>
                <li><a href="<?php  echo base_url().'superadmin/Settings/manageGroups'; ?>">Manage Groups</a></li>
                <li class="active"><span>Update Product Groups </span></li>
            </ol>
        </div> 
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="" style="padding:15px">
                    <h3> <b>Update Groups </b></h3>

                </div>
                <div class="panel-body">
                    <div class="col-md-12"> 
                      <div class="col-md-12"> 
                        <span class="success_msg" style="color:green;"></span></br>
                        <span class="fail_msg" style="color:red;"></span>
                      </div>
                   
                        <?php //print_r($groups_res); exit;
                                $row=json_decode($groups_res);
                               // print_r($row);
                                ?>
                        <?php
                        $attributes = array('name' => 'form', 'id' => 'unit-form', 'class' => 'navbar-form');
                        echo form_open_multipart('superadmin/Settings/groupUpdate/', $attributes);
                        ?>
                        <div class="form-group col-md-4 input_fields_wrap">

<?php echo form_label('Prodcut Group Code', 'group Code') . "<span style='color:red'>*" . form_error('group_code') . "</span>"; ?>
                            <br>

                            <?php
                             echo form_hidden('group_id',$row->id);
                            $data = array(
                                'name' => 'group_code',
                                'id' => 'group_code',
                                'maxlength' => '40',
                                'autocomplete' => 'off',
                                'class' => 'form-control prod_group',
                                'value'=>$row->group_code
                            );

                            echo form_input($data);
                            ?>
                          
                        </div>
                         <div class="form-group col-md-4 input_fields_wrap">

                            <?php echo form_label('Product Group Name', 'group name') . "<span style='color:red'>*" . form_error('group_name') . "</span>"; ?>
                            <br>

                            <?php
                            $data1 = array(
                                'name' => 'group_name',
                                'id' => 'group_name',
                                'maxlength' => '40',
                                'autocomplete' => 'off',
                                'class' => 'form-control prod_group',
                                'value'=>$row->group_name
                            );

                            echo form_input($data1);
                            ?>
                           
                        </div>
                       
                         <div class="clearfix"> </div>
                        <div class="form-group col-md-4 "> <br>
                            <?php echo form_submit('submit', 'Submit', array('class' => 'btn btn-success ', 'name' => 'btn_submit', 'id' => 'btn_submit')); ?>


                        </div>


                        </form>
                        <span class="help_block"></span>
                    </div>
                </div>
            </div>
        </div>
        <!-- content ends hear  -->				
        <?php $this->load->view('includes/footer'); ?>	
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>additional-methods.min.js"></script>
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.validate.min.js"></script>
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.min.js"></script>
    </body>
</html>

<script>
//     $('#unit-form').on('submit', function (i) {
//         i.preventDefault();
//         str = true;
//         $('.prod_group').each(function () {
//             if (this.value == null || this.value == "") {
//                 $(this).css('border', '1px solid red');
//                 $(this).next('#unit_error').html('<b style="color:red;">Enter Unit code</b>');
//                 str = false;
//             } else {
//                 $(this).css('border','');
//             }
//         });
//         if(str = true){
//              $.ajax({
//                         dataType: 'JSON',
//                         method: 'POST',
//                         data: new FormData(this),
//                         url: "<?php echo base_url(); ?>superadmin/Settings/insertGroups",
//                         contentType: false,
//                         cache: false,
//                         processData: false,
//                         success: function (data) {
//                             console.log(data);
//                             switch (data.code)
//                             {
//                                 case 200:

//                                     $('.success_msg').html(data.description).addClass('alert alert-success fade in');
//                                     setTimeout(function () {
//                                         window.location = "<?php echo base_url(); ?>superadmin/Settings/manageGroups";
//                                     }, 3000);
//                                     break;
//                                 case 204:
//                                     $('.fail_msg').html(data.description).addClass('alert alert-success fade in');
//                                     $('#btn_submit').show();
//                                     setTimeout(function () {
//                                         window.location = "<?php echo base_url(); ?>superadmin/Settings/createGroups";
//                                     }, 3000);
//                                 case 301:
//                                 case 422:
//                                 case 575:
//                                     $('.success_msg').html(data.description).addClass('alert alert-danger fade in');
// //                                            $('.form_loading_hide').show();
// //                                            $('.form_loading_show').hide();
//                                     break;
//                             }
//                         },
//                         error: function (error) {
//                             console.log(error);
//                         },
//                     });
//         }
//     })
    
//     $(document).ready(function () {
//         var max_fields = 10; //maximum input boxes allowed
//         var wrapper = $(".input_fields_wrap"); //Fields wrapper
//         var add_button = $(".add_field_button"); //Add button ID

//         var x = 1; //initlal text box count
//         $(add_button).click(function (e) { //on add input button click
//             e.preventDefault();
//             if (x < max_fields) { //max input box allowed
//                 x++; //text box increment
//                 $(wrapper).append('<div class="form-group mrtop"><input type="text" name="group_code[]" class="form-control prod_group" placeholder="Enter Group code "/><a href="#" class="remove_field  btn btn-sm btn-danger"><i class="glyphicon glyphicon-remove"></i></a></div><div class="clearfix"></div>'); //add input box
//             }
//         });

//         $(wrapper).on("click", ".remove_field", function (e) { //user click on remove text
//             e.preventDefault();
//             $(this).parent('div').remove();
//             x--;
//         })
//     });
</script>
