<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Manage Product Groups | Super Admin </title><!-- 
            <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH; ?>default.css" />
        <style>
            p{
                display: inline-block;
                padding-left: 0;
                margin: 20px 0;
                border-radius: 4px;} 
            p a{
              
                padding: 6px 12px;
                margin-left: -1px;
                line-height: 1.42857143;
                color: #337ab7;
                text-decoration: none;
                background-color: #fff;
                border: 1px solid #ddd;
            }
            p>a:hover{
                z-index: 2;
                color: #23527c;
                background-color: #eee;
                border-color: #ddd;

            } 
            p strong{
                background-color: #337ab7;
                padding: 6px 12px;
                color:#fff;
                border-color: #fff;

            }
        </style>

    </head>
    <body>

        <?php $this->load->view('includes/header'); ?>
        <div class="col-md-12"> 
            <ol class="breadcrumb breadcrumb-arrow">
                <li><a href="<?php echo base_url() . 'superadmin/dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
                <li><a href="">Settings</a></li>
                <li class="active"><span>Manage Product Groups </span></li>
            </ol>
        </div> 

        <div class="col-lg-12">
                <span id="successmessage" ></span>
            <div class="panel panel-default">
                <!-- <div class="col-md-12"> 
                        <ol class="breadcrumb breadcrumb-arrow">
                                <li><a href="dashboard.html"><i class="glyphicon glyphicon-th" aria-hidden="true"></i> Dashboard</a></li>
                                <li><a href="">Hostel Owners</a></li>
                                <li class="active"><span>Manage All Hostels</span></li>
                        </ol>
                </div>  -->
                <div class="" style="padding:15px">
                    <h3> <b> Manage Product Groups </b></h3>
                </div>

                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="col-md-12"> 
                        <table width="100%" class="table " id="">
                            <thead>

                                <tr>
                                    <td> 
                                        <div class="input-group">

                                            <input type="text" class="form-control" placeholder="Search for...">
                                            <span class="input-group-btn">
                                                <button class="btn btn-secoundary" type="button"><i class="glyphicon glyphicon-search"></i></button>
                                            </span>
                                        </div>
                                    </td>

                                    <td> 
                                        <button class="btn btn-success "  onclick="updateActivationStatus('1')" ><i class="fa fa-check" aria-hidden="true"></i>&nbsp;Active</button>
                                        <button class="btn btn-warning btn-md"  onclick="updateActivationStatus('0')"><i class="fa fa-ban" aria-hidden="true"></i>&nbsp;In active</button>

                                        <a href="<?php echo base_url() . 'superadmin/Settings/createGroups'; ?>" class="btn btn-sm btn-primary " ><i class="glyphicon glyphicon-plus"></i>  Create New </a> 
                                        <a href="" class="btn btn-sm btn-info "><i class="glyphicon glyphicon-sort-by-order"></i>  Set Priority </a> 
                                        <a href="" class="btn btn-sm btn-danger "><i class="glyphicon glyphicon-remove"></i>  Delete </a> 
                                    </td>

                                </tr>
                            </thead>

                        </table>


                    </div>
                    <?php
                    $result = json_decode($common_result);
                    //print_r($result);exit;
                    //print_r($result->units_list);

                    ;
                    ?>
                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
<?php if (!empty($re)) {
    echo $re;
} ?>
                        <thead>

                            <tr>
                                <th>
                                    <input type="checkbox" id="checkAll"  >
                                </th>
                                <th>Sl.No</th>
                                <th> Product Group Code </th>
                                <th> Product Group Name </th>
                                <th> Created on </th>
                                <th> Active status </th>
                                <th> Action </th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;

                            foreach ($result->common_result as $row) {
                                ?>
                                <tr class="">
                                    <td><input type="checkbox" class="inline-checkbox" name="multiple[]" value="<?php echo $row->id; ?>"  </td>
                                    <td><?php echo $i; ?> </td>
                                    <td>  <?php echo $row->group_code; ?></td>
                                    <td>  <?php echo $row->group_name; ?></td>
                                    <td> <?php echo $row->created_on; ?> </td>
                                    <td> <?php echo $row->active_status; ?> </td>
                                    <td> 
                                        <a href="<?php echo base_url(); ?>superadmin/Settings/groupsDelete/<?php echo $row->id; ?>" class="btn btn-sm btn-danger " onclick="return confirm('Are you sure?')"> Delete <i class="glyphicon glyphicon-trash"></i> </a> 
                                        <a href="<?php echo base_url(); ?>superadmin/Settings/getGroups/<?php echo $row->id; ?>" class="btn btn-sm btn-warning "> Update <i class="glyphicon glyphicon-upload"> </i> </a>
                                    </td>
                                </tr>
    <?php
    $i++;
}
?>


                        </tbody>
                    </table>
                    <!-- /.table-responsive -->

                    <div class="text-center"> 
                        <p> <?php echo $links; ?></p>

                    </div>
                </div>

                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->

        </div>
        <!-- /.col-lg-12 -->
<?php $this->load->view('includes/footer'); ?>	
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
    </body>
</html>
<script type="text/javascript">
                    $("#checkAll").change(function () {
                        $("input:checkbox").prop('checked', $(this).prop("checked"));
                    });

                    $('#menu_id').on('change', function () {
                        var menu = $(this).val();
                        if (menu > 0 && !isNaN(menu)) {
                            $('#submenu_id').html('');
                            $.ajax({
                                dataType: 'html',
                                method: 'POST',
                                data: {'menu': menu, 'submenuid': 'submenuid'},
                                url: '<?php echo base_url(); ?>superadmin/Category/submenuWithMenu',
                                success: function (ss) {
                                    console.log(ss);
                                    $('#submenu_id').html(ss);
                                },
                                error: function (se) {
                                    console.log(se);
                                }
                            });
                        }
                    });
                    $('#submenu_id').on('change', function () {
                        var submenu = $(this).val();
                        if (submenu > 0 && !isNaN(submenu)) {
                            $('#listsubmenu').html('');
                            $.ajax({
                                dataType: 'html',
                                method: 'POST',
                                data: {'submenu': submenu},
                                url: '<?php echo base_url(); ?>Superadmin/Category/listSubMenuWithMenu',
                                success: function (ss) {
                                    $('#listsubmenu').html(ss);
                                },
                                error: function (se) {
                                    console.log(se);
                                }
                            });
                        }
                    });

                    function updateActivationStatus(s) {

                        var listarray = new Array();
                        $('input[name="multiple[]"]:checked').each(function () {
                            listarray.push($(this).val());
                        });
                        //alert(listarray);
                        var checklist = "" + listarray;
                        //alert(checklist);
                        if (!isNaN(s) && (s == '1' || s == '0') && checklist != '') {
                            $('#fail').hide();
                            $.ajax({
                                dataType: 'json',
                                type: 'post',
                                data: {'tablename': 'groups', 'updatelist': checklist, 'activity': s},
                                url: '<?php echo base_url(); ?>superadmin/Settings/commonStatusActivity/',
                                success: function (u) {
                                    console.log(u);
                                    if (u.code == '200') {
                                        $('#success').show();
                                        $('#successmessage').html(u.description);
                                        setTimeout(function () {
                                            window.location = location.href;
                                        }, 2000);
                                    }
                                    if (u.code == '204' || u.code == '301' || u.code == '422') {
                                        $('#fail').show();
                                        $('#failmessage').html(u.description);
                                    }
                                },
                                error: function (er) {
                                    console.log(er);
                                }
                            });
                        } else {
                            $('#fail').show();
                            $('#failmessage').html('*  Please select a record');
                        }
                    }
</script>