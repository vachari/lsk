<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Create Menu </title><!-- 
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />
	
  </head>
  <body>
	<?php include('includes/header.php'); ?>
	<!-- content Starts  hear  -->	

		<div class="col-md-12"> 
			<ol class="breadcrumb breadcrumb-arrow">
				<li><a href="<?php echo base_url().'dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
				<li><a href="">Category</a></li>
				<li><a href="">Manage Category</a></li>
				<li class="active"><span>update Category </span></li>
			</ol>
		</div> 
	<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="" style="padding:15px">
					<h3> <b> Update Menu</b></h3>
				</div>
				<div class="panel-body">
					<div class="col-md-12"> 

						<?php 
							$attribute = array('name' =>'form' ,'id'=> 'register-form');
						echo form_open('superadmin/Category/update_menu',$attribute); ?>
		                  <!--   <form class="" method="post" action="" > -->
		                 <?php 
					       if(validation_errors()){
					     ?>
					       <div class="alert alert-danger">
					       <?php echo validation_errors();?>
					       </div> 
					    <?php
					       }
						   
						
					    ?>
								<?php $attr=array('name'=>'menu_id','value'=>$result->menu_id);
									echo form_hidden($attr);

								?>
						        <div class="form-group col-xs-4">
						        <?php echo form_label('Menu Name','Menu Name'); ?>
						        <span style="color:red;"> *</span> 
						        <?php
								//print_r($result);exit;
									 $id= $this->uri->segment(4);
						        	$data = array(
											        'name'          => 'menu_title',
											        'id'            => 'menu_title',
											        'maxlength'     => 40,
											        'autocomplete'  => 'off',
											        'class'			=> 'form-control',
													'value'			=>$result->menu_title
											);

						         echo form_input($data);
								 ?> 
								 
						          
						        </div>
				
						        <div class="clearfix"></div>
						        <div class="form-group col-xs-4 ">
						         <?php echo form_submit('addmenu','Submit',array('class'=>'btn btn-success','name'=>'btn_submit','id'=>'btn_submit')); ?>
						       		</div>
						    </form>
						   
	                      <span class="help_block"></span>
	                </div>
				</div>
			</div>
		</div>
		<!-- content ends hear  -->				
    <?php include('includes/footer.php'); ?>	
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>additional-methods.min.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.validate.min.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.min.js"></script>
	
     
  </body>
</html>
<script>

$(function(){
	 $.validator.setDefaults({
    errorClass: 'help-block',
    highlight: function(element) {
      $(element)
        .closest('.form-group')
        .addClass('has-error');
    },
    unhighlight: function(element) {
      $(element)
        .closest('.form-group')
        .removeClass('has-error');
    },
    errorPlacement: function (error, element) {
      if (element.prop('type') === 'checkbox') {
        error.insertAfter(element.parent());
      } else {
        error.insertAfter(element);
      }
    }
  });

  
	$("#register-form").validate({
		rules:{
			//name fields
			menu_title:{
				required:true,
				nowhitespace:true, 
				lettersonly:true
			},
			email:{
				required:true,
				email:true
			},
			password:{
				required:true,
			
			}
			
			
		},
		messages:{
			required:'Please Enter Your Email',
			email:'please enter a valid email address'
		}
	});
});

</script>