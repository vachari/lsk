<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Super Admin </title><!-- 
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />
	
  </head>
  <body>
		<?php include('includes/header.php'); ?>
            	<div class="col-md-12"> 
					<ol class="breadcrumb breadcrumb-arrow">
						<li><a href="<?php echo base_url().'dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
						<li><a href=""><?php echo $this->uri->segment(3); ?></a></li>
						<li class="active"><span>Manage Orders </span></li>
					</ol>
				</div> 
				
					<div class="col-md-12">
							
							<div class="panel panel-default">
								<!-- <div class="col-md-12"> 
									<ol class="breadcrumb breadcrumb-arrow">
										<li><a href="dashboard.html"><i class="glyphicon glyphicon-th" aria-hidden="true"></i> Dashboard</a></li>
										<li><a href="">Hostel Owners</a></li>
										<li class="active"><span>Manage All Hostels</span></li>
									</ol>
								</div>  -->
								<div class="" style="padding:15px">
									<h3> <b> View Order Details	 </b></h3>
								</div>
								
								<!-- /.panel-heading -->
								<div class="panel-body">
									<div class="col-md-4"> 
											<h2> Order Details</h2>
										<table class="table table-striped col-md-6"> 
											<tr> 
												<th> Order Id </th>
											</tr>
											<tr>	
												<th> Order Date	 </th>
											</tr>
											<tr>
												<th> Order Status </th>

											</tr>
											

										</table>
										
									</div>
									<div class="col-md-4"> 
										<h2> Shipping Details</h2>
										<table class="table table-striped col-md-6"> 
											<tr> 
												<th> Title </th>
											</tr>
											<tr> 
												<th> Names	 </th>
											</tr>
											<tr> 
											     <th> Phone </th>
											</tr>
											<tr> 
												<th> Phone </th>
											</tr>


										</table>

									</div>
								
									<div class="clearfix">  </div>
						<div class="text-center"> 
								<nav aria-label="Page navigation">
								  <ul class="pagination">
								   	<li class="disabled"><a href="#" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a>
								   	</li>
    								<li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
								    <li><a href="#">2</a></li>
								    <li><a href="#">3</a></li>
								    <li><a href="#">4</a></li>
								    <li><a href="#">5</a></li>
								    <li>
								      <a href="#" aria-label="Next">
								        <span aria-hidden="true">&raquo;</span>
								      </a>
								    </li>
								  </ul>
								</nav>

						</div>
								</div>
								
								<!-- /.panel-body -->
							</div>
							<!-- /.panel -->
							
						</div>
						<!-- /.col-lg-12 -->
    			<?php include('includes/footer.php'); ?>	
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
  </body>
</html>
<script type="text/javascript">
	$("#checkAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});



</script>