<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Create Sub List Category </title><!-- 
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />
	
  </head>
  <body>
	<?php include('includes/header.php'); ?>
	<!-- content Starts  hear  -->	

		<div class="col-md-12"> 
			<ol class="breadcrumb breadcrumb-arrow">
				<li><a href="<?php echo base_url().'dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
				<li><a href="">Category</a></li>
				<li class="active"><span>Update Listsub Category </span></li>
			</ol>
		</div> 
	<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="" style="padding:15px">
					<h3> <b> Update Listsub Category </b></h3>
					
				</div>
				<div class="panel-body">
					<div class="col-md-12"> 
							<?php //print_r($rlt);
									 $rlt->listsubmenu_id;
							   ?>

		                    <?php
		                    	$attributes = array('name' =>'form' ,'id'=> 'register-form');
		                    	 echo form_open_multipart('superadmin/Category/updatesublistCategory',$attributes); ?>
		                    	 <div class="form-group col-xs-4">
		                    	 
		                    	 <?php echo form_hidden('listsubmenu_id',$rlt->listsubmenu_id) ?>
								<?php echo  form_hidden('old_banner',$rlt->listsubmenu_banner) ?>
								<?php echo form_hidden('old_app_ico',$rlt->listsubmenu_app_icon) ?>

								<?php echo form_label('Choose Category ','Choose Category ')."<span style='color:red'>*".form_error('menu_id')."</span>"; ?>
						      
									
									<select name="menu_id" id="" class="form-control ">


										<?php 

										for($i=0;$i<count($menu_result);$i++){
											
										?>
										<option value="<?php echo $menu_result[$i]->menu_id;?>" 
											<?php
										if($rlt->menu_id==$menu_result[$i]->menu_id)
											{
												echo ' selected';
											}
										?> >
										<?php echo $menu_result[$i]->menu_title; ?>
											
										</option>
										<?php
											}
									?>
									
									</select>
								</div>
								<div class="form-group col-xs-4">
								
								<?php echo form_label('Choose Sub Category','Choose Sub Category')."<span style='color:red'>*".form_error('submenu_id')."</span>";?>
						        
									<select name="submenu_id" id="" class="form-control ">
										<?php 

										for($i=0;$i<count($result);$i++){
											
										?>
										<option value="<?php echo $result[$i]->submenu_id; ?>" 
											<?php
										if($rlt->submenu_id==$result[$i]->submenu_id)
											{
												echo 'selected';
											}
										?> >
										<?php echo $result[$i]->submenu_title; ?>
											
										</option>
										<?php
											}
									?>
									
									
									</select>
								</div>
						        <div class="form-group col-xs-4">
						        	<?php echo form_label('Listsub Category Title','Listsub Category Title')."<span style='color:red'>*".form_error('listsubmenu_title')."</span>"; ?>
						        
						        	
						        	<?php
					        	$data = array(
										        'name'          => 'listsubmenu_title',
										        'id'            => 'menu_title',
										        'maxlength'     => '40',
										        'autocomplete'  => 'off',
										        'class'			=> 'form-control',
										        'placeholder'	=> 'Enter listsub category',
										        'value'			=> $rlt->listsubmenu_title


										);

						         echo form_input($data);?>
						         	
						        </div>
						        <div class="clearfix"> </div>
						        <div class="form-group col-xs-4"> 
						        	<?php echo form_label('IMAGE (250 X 150)','IMAGE (250 X 150)'); ?>
						        <span style="color:red;"> *</span> 
						        	
						        	<?php
						        	$upload1 = array(
											        'name'          => 'image',
											        'id'            => 'image',
											        'class'			=> 'form-control'
											);

						         echo form_upload($upload1);?>
								</div>
								<div class="form-group col-xs-4"> 
						        	<?php echo form_label('App Icon (100 X 80)','App Icon'); ?>
						        <span style="color:red;"> *</span> 
						        	
						        	<?php
						        	$upload2 = array(
											        'name'          => 'icon',
											        'id'            => 'icon',
											        'class'			=> 'form-control'
											);

						         echo form_upload($upload2);?>
						        	
								</div>
								
								<div class="clearfix"> </div>
								<div class="form-group col-xs-8 pull-right"> 
								 <?php echo form_submit('submit','Submit',array('class'=>'btn btn-success','name'=>'btn_submit','id'=>'btn_submit')); ?>
						        	
						        	<!-- <a href="<?php echo base_url().'superadmin/Category/managesublistmenu'; ?> " class="btn btn-primary btn-md	"> <i class="glyphicon glyphicon-eye-open"></i> View Sub List Menus</a> -->
								</div>
						        	
						        	
						    </form>
	                      <span class="help_block"></span>
	                </div>
				</div>
			</div>
		</div>
		<!-- content ends hear  -->				
    <?php include('includes/footer.php'); ?>	
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>additional-methods.min.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.validate.min.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.min.js"></script>
	 </body>
</html>

<script>
$(function(){
	 $.validator.setDefaults({
    errorClass: 'help-block',
    highlight: function(element) {
      $(element)
        .closest('.form-group')
        .addClass('has-error');
    },
    unhighlight: function(element) {
      $(element)
        .closest('.form-group')
        .removeClass('has-error');
    },
    errorPlacement: function (error, element) {
      if (element.prop('type') === 'checkbox') {
        error.insertAfter(element.parent());
      } else {
        error.insertAfter(element);
      }
    }
  });

  $.validator.addMethod('strongPassword', function(value, element) {
    return this.optional(element) 
      || value.length >= 6
      && /\d/.test(value)
      && /[a-z]/i.test(value);
  }, 'Your password must be at least 6 characters long and contain at least one number and one char\'.')

	$("#register-form").validate({
		rules:{
			//name fields

			menu_id:{
				required:true
				 
				
			},
			submenu_id:{
				required:true
				 
				
			},
			
			listsubmenu_title:{
				required:true
			}
			
			
			
		},
		messages:{
			required:'Please Enter Your Email',
			email:'please enter a valid email address'
		}
	});
	
});
</script>