<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Change Password  </title><!-- 
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo SUPER_CSS_PATH ; ?>default.css" />
	
  </head>
  <body>
	<?php include('includes/header.php'); ?>
	<!-- content Starts  hear  -->	

		<div class="col-md-12"> 
			<ol class="breadcrumb breadcrumb-arrow">
				<li><a href="<?php echo base_url().'superadmin/dashboard'; ?>"><i class="glyphicon glyphicon-home" aria-hidden="true"></i></a></li>
				<!-- <li><a href="">Change Password</a></li> -->
				<li class="active"><span>Change Password</span></li>

			</ol>
		</div> 
	<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="" style="padding:15px">
					<h3> <b> Change Password </b></h3>
					<?php if($this->session->flashdata('success')){?>
			          <div class="alert alert-success">      
			            <?php echo $this->session->flashdata('success')?>
			          </div>
			        <?php } ?> 
			        <?php if($this->session->flashdata('error')){?>
			          <div class="alert alert-danger">      
			            <?php echo $this->session->flashdata('error')?>
			          </div>
			        <?php } ?> 

					   <?php //if(!empty($result)){extract($result); echo $msg;} ?>
					  
					    
				</div>
				<div class="panel-body">
					<div class="col-md-12"> 
					 <div class="col-md-12 text-danger">
					  
					 </div>
						<?php $attributes = array('name' =>'form' ,'id'=> 'register-form');
						         echo form_open_multipart('',$attributes); ?>
						         
								<div class="form-group form-group col-xs-12 col-md-4 col-sm-4 col-lg-4"> 
								<?php echo form_label('Old Password ','Old Password ')."<span style='color:red'>*".form_error('old_password')."</span>"; ?>
						      		<?php
						        	$data8= array(
											        'name'          => 'old_password',
											        'id'            => 'old_password',
											        'maxlength'     => 40,
											        'autocomplete'  => 'off',
											        'class'			=> 'form-control',
											        'placeholder'	=> 'Enter Your Old Password'

											);

						         echo form_password($data8);?>
									
									
								</div>  <div class="clearfix"> </div>
						        <div class="form-group form-group col-xs-12 col-md-4 col-sm-4 col-lg-4">

						        	
						        	<?php echo form_label('New Password','New Password')."<span style='color:red'>*".form_error('new_password')."</span>"; ?>
						        
						        	
						        	<?php
						        	$data4= array(
											        'name'          => 'new_password',
											        'id'            => 'new_password',
											        'maxlength'     => 40,
											        'autocomplete'  => 'off',
											        'class'			=> 'form-control',
											        'placeholder'	=> 'Enter Your New Password'

											);

						         echo form_password($data4);?>
						         	 
						        </div>
						        <div class="clearfix"> </div>
						        <div class="form-group form-group col-xs-12 col-md-4 col-sm-4 col-lg-4"> 
									<?php echo form_label('confirm Password','confirm Password')."<span style='color:red'>*".form_error('confirm_password')."</span>"; ?>
						       
						        	
						        	<?php
						        	$data5 = array(
											        'name'          => 'confirm_password',
											        'id'            => 'confirm_password',
											        'maxlength'     => 40,
											        'autocomplete'  => 'off',
											        'class'			=> 'form-control',
											        'placeholder'	=> 'Enter Your confirm Password'

											);

						         echo form_password($data5);?>
						        	
								</div>
								
								
								<div class="clearfix"> </div>
								<div class="form-group form-group col-xs-12 col-md-4 col-sm-4 col-lg-4 "> 
									<?php echo form_submit('submit','Change Password',array('class'=>'btn btn-info','name'=>'btn_submit','id'=>'btn_submit')); ?>
								</div>
						        	<span class="help_block"></span>
						        	
						    <?php echo form_close(); ?>
						    
						   
	                </div>
				</div>
			</div>
		</div>
		<!-- content ends hear  -->				
    <?php include('includes/footer.php'); ?>	
   <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery-3.1.1.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>default.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>additional-methods.min.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.validate.min.js"></script>
     <script type="text/javascript" src="<?php echo SUPER_JS_PATH; ?>jquery.min.js"></script>
	
  </body>
</html>

<script>
$(function(){
	 $.validator.setDefaults({
    errorClass: 'help-block',
    highlight: function(element) {
      $(element)
        .closest('.form-group')
        .addClass('has-error');
    },
    unhighlight: function(element) {
      $(element)
        .closest('.form-group')
        .removeClass('has-error');
    },
    errorPlacement: function (error, element) {
      if (element.prop('type') === 'checkbox') {
        error.insertAfter(element.parent());
      } else {
        error.insertAfter(element);
      }
    }
  });

  $.validator.addMethod('strongPassword', function(value, element) {
    return this.optional(element) 
      || value.length >= 6
      && /\d/.test(value)
      && /[a-z]/i.test(value);
  }, 'Your password must be at least 6 characters long and contain at least one number and one char\'.')

	$("#register-form").validate({
		rules:{
			//name fields

			menu_id:{
				required:true
				 
				
			},
			
			submenu_title:{
				required:true
			}
			
			
			
		},
		messages:{
			required:'Please Enter Your Email',
			email:'please enter a valid email address'
		}
	});
	
});
</script>